import { db } from "./index";
import {
  restaurants,
  branches,
  users,
  diningAreas,
  diningTables,
  menuCategories,
  menuItems,
  modifiers,
  modifierOptions,
  menuItemModifiers,
  ingredients,
  recipes,
  recipeIngredients,
  suppliers,
  auditLogs,
  applicationSettings,
} from "./schema";
import { hashPassword } from "../lib/auth";
import { sql } from "drizzle-orm";

/**
 * Resets all tables to clean state and populates verified production master data.
 * Zero demo orders, zero fake payments, zero fake shifts, zero fake purchase orders.
 */
async function resetTables() {
  await db.execute(sql`
    TRUNCATE TABLE
      audit_logs, application_settings, stock_movements, stock_counts,
      goods_receipts, purchase_order_items, purchase_orders,
      refunds, payments, kitchen_tickets, order_items, orders,
      recipe_ingredients, recipes, menu_item_modifiers, modifier_options,
      modifiers, menu_items, menu_categories, ingredients, suppliers,
      dining_tables, dining_areas, shifts, users, branches, restaurants
    RESTART IDENTITY CASCADE
  `);
}

export async function seed() {
  console.log("Resetting database for production deployment...");
  await resetTables();

  console.log("Seeding production master data...");

  // 1. Restaurant Master Record
  const [restaurant] = await db
    .insert(restaurants)
    .values({
      name: "Asanka Royal Bistro & Lounge",
      legalName: "Asanka Royal Hospitality Ghana Ltd.",
      currency: "GHS",
      currencySymbol: "GH₵",
      phone: "+233 30 278 9011",
      email: "info@asankaroyal.com",
      address: "14 Senchi Street, Airport Residential Area, Accra, Ghana",
      taxNumber: "GRA-TIN-C002849102X",
      receiptHeader: "ASANKA ROYAL BISTRO & LOUNGE\nAuthentic Ghanaian Cuisine & Chop Bar Experience\n14 Senchi St, Airport Residential Area, Accra\nTel: +233 30 278 9011",
      receiptFooter: "Akwaaba! Medaase for dining with us.\nOfficial GRA Standard VAT Invoice\nWi-Fi: AsankaGuest / Pass: asankaroyal\nFollow us @asankaroyalgh",
      defaultTaxRate: "15.00",
      defaultServiceCharge: "0.00",
    })
    .returning();

  // 2. Primary Branch
  const [branch] = await db
    .insert(branches)
    .values({
      restaurantId: restaurant.id,
      name: "Accra Airport Flagship",
      code: "ACC-AP-01",
      address: "14 Senchi Street, Airport Residential Area, Accra, Ghana",
      phone: "+233 30 278 9011",
      managerName: "Kofi Mensah",
      isActive: true,
    })
    .returning();

  // 3. Production Staff Accounts with Role-Based Permissions
  const initialPassword = hashPassword("Admin123!");
  const productionStaff = [
    {
      restaurantId: restaurant.id,
      branchId: branch.id,
      name: "Nana Kwame Asante (Owner)",
      email: "admin@asankaroyal.com",
      passwordHash: initialPassword,
      pin: "1111",
      role: "super_admin" as const,
      phone: "+233 24 410 0001",
      avatarUrl: "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=150&auto=format&fit=crop&q=80",
    },
    {
      restaurantId: restaurant.id,
      branchId: branch.id,
      name: "Kofi Mensah (General Manager)",
      email: "manager@asankaroyal.com",
      passwordHash: initialPassword,
      pin: "2222",
      role: "manager" as const,
      phone: "+233 24 410 0002",
      avatarUrl: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&auto=format&fit=crop&q=80",
    },
    {
      restaurantId: restaurant.id,
      branchId: branch.id,
      name: "Akosua Serwaa (Cashier / Front-of-House)",
      email: "cashier@asankaroyal.com",
      passwordHash: initialPassword,
      pin: "3333",
      role: "cashier" as const,
      phone: "+233 24 410 0003",
      avatarUrl: "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=150&auto=format&fit=crop&q=80",
    },
    {
      restaurantId: restaurant.id,
      branchId: branch.id,
      name: "Chef Kwabena Boateng (Executive Chef)",
      email: "chef@asankaroyal.com",
      passwordHash: initialPassword,
      pin: "4444",
      role: "cook" as const, // Staff record only - kitchen operates via printed dockets, no terminal login
      phone: "+233 24 410 0004",
      avatarUrl: "https://images.unsplash.com/photo-1577219491135-ce391730fb2c?w=150&auto=format&fit=crop&q=80",
    },
    {
      restaurantId: restaurant.id,
      branchId: branch.id,
      name: "Yaw Osei (Stock Controller)",
      email: "stock@asankaroyal.com",
      passwordHash: initialPassword,
      pin: "5555",
      role: "inventory_officer" as const,
      phone: "+233 24 410 0005",
      avatarUrl: "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=150&auto=format&fit=crop&q=80",
    },
    {
      restaurantId: restaurant.id,
      branchId: branch.id,
      name: "Ama Darko (Finance Lead)",
      email: "finance@asankaroyal.com",
      passwordHash: initialPassword,
      pin: "6666",
      role: "accountant" as const,
      phone: "+233 24 410 0006",
      avatarUrl: "https://images.unsplash.com/photo-1573496359142-b8d87734a5a2?w=150&auto=format&fit=crop&q=80",
    },
  ];

  const createdStaff = await db.insert(users).values(productionStaff).returning();
  const [adminUser] = createdStaff;

  // 4. Dining Areas
  const [areaMain, areaPatio, areaBar, areaVip] = await db
    .insert(diningAreas)
    .values([
      { branchId: branch.id, name: "Asanka Main Chop Hall", sortOrder: 1 },
      { branchId: branch.id, name: "Osu Garden & Grill Terrace", sortOrder: 2 },
      { branchId: branch.id, name: "Palm Wine & Cocktail Bar", sortOrder: 3 },
      { branchId: branch.id, name: "Akwaaba VIP Executive Cellar", sortOrder: 4 },
    ])
    .returning();

  // Dining Tables - All initialized cleanly as AVAILABLE with zero active orders
  await db.insert(diningTables).values([
    // Main Chop Hall
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-01", capacity: 2, status: "available", posX: 50, posY: 50, shape: "square" },
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-02", capacity: 4, status: "available", posX: 150, posY: 50, shape: "rectangle" },
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-03", capacity: 4, status: "available", posX: 250, posY: 50, shape: "rectangle" },
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-04", capacity: 6, status: "available", posX: 350, posY: 50, shape: "rectangle" },
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-05", capacity: 4, status: "available", posX: 50, posY: 180, shape: "square" },
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-06", capacity: 4, status: "available", posX: 150, posY: 180, shape: "square" },
    { areaId: areaMain.id, branchId: branch.id, tableNumber: "T-07", capacity: 8, status: "available", posX: 280, posY: 180, shape: "rectangle" },
    // Garden Terrace
    { areaId: areaPatio.id, branchId: branch.id, tableNumber: "P-01", capacity: 2, status: "available", posX: 50, posY: 50, shape: "circle" },
    { areaId: areaPatio.id, branchId: branch.id, tableNumber: "P-02", capacity: 4, status: "available", posX: 150, posY: 50, shape: "circle" },
    { areaId: areaPatio.id, branchId: branch.id, tableNumber: "P-03", capacity: 4, status: "available", posX: 250, posY: 50, shape: "circle" },
    // Palm Wine Bar
    { areaId: areaBar.id, branchId: branch.id, tableNumber: "BAR-01", capacity: 1, status: "available", posX: 50, posY: 50, shape: "circle" },
    { areaId: areaBar.id, branchId: branch.id, tableNumber: "BAR-02", capacity: 1, status: "available", posX: 100, posY: 50, shape: "circle" },
    { areaId: areaBar.id, branchId: branch.id, tableNumber: "BAR-03", capacity: 1, status: "available", posX: 150, posY: 50, shape: "circle" },
    { areaId: areaBar.id, branchId: branch.id, tableNumber: "BAR-04", capacity: 2, status: "available", posX: 200, posY: 50, shape: "circle" },
    // VIP Lounge
    { areaId: areaVip.id, branchId: branch.id, tableNumber: "VIP-GOLD", capacity: 12, status: "available", posX: 100, posY: 100, shape: "rectangle" },
  ]);

  // 5. Ghanaian Menu Categories
  const categories = await db
    .insert(menuCategories)
    .values([
      { branchId: branch.id, name: "Jollof & Rice Specialties", slug: "jollof-rice", icon: "Utensils", sortOrder: 1 },
      { branchId: branch.id, name: "Traditional Soups & Swallows", slug: "soups-swallows", icon: "Soup", sortOrder: 2 },
      { branchId: branch.id, name: "Charcoal Grills & Chop Bites", slug: "grills-bites", icon: "Flame", sortOrder: 3 },
      { branchId: branch.id, name: "Stews & Plantain Delights", slug: "stews-plantain", icon: "Salad", sortOrder: 4 },
      { branchId: branch.id, name: "Artisan Street Snacks", slug: "street-snacks", icon: "Ham", sortOrder: 5 },
      { branchId: branch.id, name: "Local Beverages & Cocktails", slug: "beverages", icon: "Wine", sortOrder: 6 },
      { branchId: branch.id, name: "Ghanaian Sweets & Desserts", slug: "desserts", icon: "Cake", sortOrder: 7 },
    ])
    .returning();

  const [catRice, catSoups, catGrills, catStews, catSnacks, catDrinks, catDesserts] = categories;

  // 6. Authentic Ghanaian Menu Offerings
  const items = await db
    .insert(menuItems)
    .values([
      // Jollof & Rice Specialties
      {
        categoryId: catRice.id,
        name: "Authentic Ghana Smoky Jollof Rice",
        description: "Smoky fragrant Jasmine rice simmered in rich tomato, ginger, garlic, rosemary and shito base. Served with golden fried sweet plantain (dodo).",
        sku: "GHA-JOL-01",
        price: "75.00",
        costPrice: "22.00",
        imageUrl: "https://images.unsplash.com/photo-1568901346375-23c9450c58cd?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 12,
        station: "kitchen",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      {
        categoryId: catRice.id,
        name: "Royal Waakye Platter Special",
        description: "Rice and black-eyed beans cooked with red sorghum leaves. Served with talia (spaghetti), gari foto, boiled farm egg, wele (cow foot), and authentic spicy black shito.",
        sku: "GHA-WAK-01",
        price: "85.00",
        costPrice: "26.00",
        imageUrl: "https://images.unsplash.com/photo-1546069901-ba9599a7e63c?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 10,
        station: "kitchen",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      // Charcoal Grills
      {
        categoryId: catGrills.id,
        name: "Charcoal-Grilled Volta Lake Whole Tilapia",
        description: "Fresh whole tilapia marinated with ginger, garlic, aniseed, and scotch bonnet peppers, charcoal-grilled to perfection. Served with two steaming hot Banku balls and freshly ground green & red asanka pepper.",
        sku: "GHA-TIL-01",
        price: "120.00",
        costPrice: "45.00",
        imageUrl: "https://images.unsplash.com/photo-1519708227418-c8fd9a32b7a2?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 20,
        station: "grill",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      {
        categoryId: catGrills.id,
        name: "Kyinkyinga Spiced Beef Suya Kebabs (4 Skewers)",
        description: "Tender beef skewers crusted with roasted peanut kuli-kuli powder, ginger, garlic, cloves, and chili pepper, flash-grilled over charcoal with sliced red onions.",
        sku: "GHA-KYN-01",
        price: "65.00",
        costPrice: "18.00",
        imageUrl: "https://images.unsplash.com/photo-1558030006-450675393462?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 10,
        station: "grill",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      // Traditional Soups & Swallows
      {
        categoryId: catSoups.id,
        name: "Fufu with Rich Light Soup & Tender Goat Meat",
        description: "Pounded cassava and plantain fufu served immersed in spicy aromatic tomato-ginger light soup with tender bone-in goat meat and garden eggs.",
        sku: "GHA-FUF-01",
        price: "95.00",
        costPrice: "32.00",
        imageUrl: "https://images.unsplash.com/photo-1604909052743-94e838986d24?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 15,
        station: "kitchen",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      {
        categoryId: catSoups.id,
        name: "Banku with Fresh Okro Soup & Blue Sea Crab",
        description: "Fermented corn and cassava banku served with viscous chopped okro soup cooked with red palm oil, blue sea crabs, smoked catfish, and tender beef.",
        sku: "GHA-BNK-01",
        price: "90.00",
        costPrice: "30.00",
        imageUrl: "https://images.unsplash.com/photo-1574071318508-1cdbab80d002?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 14,
        station: "kitchen",
        isAvailable: true,
        isFeatured: false,
        hasRecipe: true,
      },
      {
        categoryId: catSoups.id,
        name: "Peanut Groundnut Soup with Smoked Guinea Fowl",
        description: "Velvety roasted peanut and tomato soup infused with herbs, smoked Northern Ghana guinea fowl, and steamed fufu or omotuo (rice balls).",
        sku: "GHA-GNT-01",
        price: "110.00",
        costPrice: "38.00",
        imageUrl: "https://images.unsplash.com/photo-1551183053-bf91a1d81141?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 15,
        station: "kitchen",
        isAvailable: true,
        isFeatured: false,
        hasRecipe: true,
      },
      // Stews & Plantain Delights
      {
        categoryId: catStews.id,
        name: "Kontomire (Cocoyam Leaf) Stew with Boiled Yam & Koobi",
        description: "Steamed tender cocoyam leaves simmered in palm oil with melon seeds (egusi), salted dried tilapia (koobi), and boiled farm eggs. Served with soft boiled yam.",
        sku: "GHA-KNT-01",
        price: "80.00",
        costPrice: "24.00",
        imageUrl: "https://images.unsplash.com/photo-1513104890138-7c749659a591?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 14,
        station: "kitchen",
        isAvailable: true,
        isFeatured: false,
        hasRecipe: true,
      },
      // Artisan Street Snacks
      {
        categoryId: catSnacks.id,
        name: "Spicy Kelewele (Fried Spiced Plantain Cubes)",
        description: "Sweet ripe plantain cubes marinated in crushed ginger, cayenne, cloves, nutmeg, and sea salt, fried golden and served with roasted crunchy groundnuts.",
        sku: "GHA-KLW-01",
        price: "35.00",
        costPrice: "8.50",
        imageUrl: "https://images.unsplash.com/photo-1573080496219-bb080dd4f877?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 8,
        station: "kitchen",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      {
        categoryId: catSnacks.id,
        name: "Crispy Fried Yam Batons with Spicy Turkey Tails (Tsofi)",
        description: "Deep-fried Pona yam batons paired with seasoned crispy turkey tails (Tsofi), raw sliced onions, and spicy green kpakpo shito.",
        sku: "GHA-YAM-01",
        price: "60.00",
        costPrice: "16.00",
        imageUrl: "https://images.unsplash.com/photo-1586190848861-99aa4a171e90?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 10,
        station: "kitchen",
        isAvailable: true,
        isFeatured: false,
        hasRecipe: true,
      },
      // Beverages & Cocktails
      {
        categoryId: catDrinks.id,
        name: "Fresh Chilled Sobolo with Pineapple & Ginger",
        description: "Steeped dried hibiscus sabdariffa flowers infused with fresh pineapple juice, crushed spicy ginger, grains of selim (hwentia), and cloves.",
        sku: "GHA-SBL-01",
        price: "30.00",
        costPrice: "6.00",
        imageUrl: "https://images.unsplash.com/photo-1514362545857-3bc16c4c7d1b?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 3,
        station: "bar",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
      {
        categoryId: catDrinks.id,
        name: "Ice-Cold Club Premium Lager Beer (625ml)",
        description: "Ghana's timeless crisp premium lager beer from Accra Brewery Limited, served ice-cold with a chilled glass.",
        sku: "GHA-CLB-01",
        price: "25.00",
        costPrice: "14.00",
        imageUrl: "https://images.unsplash.com/photo-1608270199147-9f170327f12e?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 1,
        station: "bar",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: false,
      },
      {
        categoryId: catDrinks.id,
        name: "Fresh Tapped Palm Wine Cocktail & Lime",
        description: "Freshly tapped sweet palm wine mixed with small-batch ginger infusion and fresh lime juice on the rocks.",
        sku: "GHA-PLM-01",
        price: "45.00",
        costPrice: "11.00",
        imageUrl: "https://images.unsplash.com/photo-1560512823-829485b8bf24?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 3,
        station: "bar",
        isAvailable: true,
        isFeatured: false,
        hasRecipe: true,
      },
      // Sweets & Desserts
      {
        categoryId: catDesserts.id,
        name: "Warm Ghana Dark Cocoa Lava Cake",
        description: "Molten chocolate cake crafted from 72% premium single-origin Ghanaian cocoa beans with sweet vanilla cream.",
        sku: "GHA-DS-01",
        price: "45.00",
        costPrice: "12.00",
        imageUrl: "https://images.unsplash.com/photo-1606313564200-e75d5e30476c?w=400&auto=format&fit=crop&q=80",
        prepTimeMinutes: 10,
        station: "kitchen",
        isAvailable: true,
        isFeatured: true,
        hasRecipe: true,
      },
    ])
    .returning();

  // 7. Modifiers & Options
  const [modProtein] = await db
    .insert(modifiers)
    .values([
      { name: "Extra Protein / Meat Choice", minSelection: 0, maxSelection: 3, isRequired: false },
    ])
    .returning();

  const [modPepper] = await db
    .insert(modifiers)
    .values([
      { name: "Pepper & Shito Preference", minSelection: 1, maxSelection: 1, isRequired: true },
    ])
    .returning();

  const [modSides] = await db
    .insert(modifiers)
    .values([
      { name: "Additional Accompaniment", minSelection: 0, maxSelection: 2, isRequired: false },
    ])
    .returning();

  await db.insert(modifierOptions).values([
    // Protein options
    { modifierId: modProtein.id, name: "Grilled Quarter Chicken", priceDelta: "20.00", sortOrder: 1 },
    { modifierId: modProtein.id, name: "Tender Goat Meat Portion", priceDelta: "30.00", sortOrder: 2 },
    { modifierId: modProtein.id, name: "Fried Red Snapper Fish", priceDelta: "25.00", sortOrder: 3 },
    { modifierId: modProtein.id, name: "Boiled Farm Egg", priceDelta: "5.00", sortOrder: 4 },
    { modifierId: modProtein.id, name: "Wele (Cow Skin)", priceDelta: "10.00", sortOrder: 5 },
    // Pepper options
    { modifierId: modPepper.id, name: "Extra Black Shito", priceDelta: "0.00", sortOrder: 1 },
    { modifierId: modPepper.id, name: "Fresh Green Kpakpo Shito", priceDelta: "0.00", sortOrder: 2 },
    { modifierId: modPepper.id, name: "Mild Spiced (Low Pepper)", priceDelta: "0.00", sortOrder: 3 },
    { modifierId: modPepper.id, name: "Hot Hot Scotch Bonnet", priceDelta: "0.00", sortOrder: 4 },
    // Side options
    { modifierId: modSides.id, name: "Extra Fried Sweet Plantain", priceDelta: "15.00", sortOrder: 1 },
    { modifierId: modSides.id, name: "Extra Steaming Banku Ball", priceDelta: "8.00", sortOrder: 2 },
    { modifierId: modSides.id, name: "Extra Talia (Spaghetti)", priceDelta: "10.00", sortOrder: 3 },
    { modifierId: modSides.id, name: "Extra Fried Yam Batons", priceDelta: "15.00", sortOrder: 4 },
  ]);

  // Link modifiers to menu items
  const jollofItem = items.find((i) => i.sku === "GHA-JOL-01");
  const waakyeItem = items.find((i) => i.sku === "GHA-WAK-01");
  const tilapiaItem = items.find((i) => i.sku === "GHA-TIL-01");
  const suyaItem = items.find((i) => i.sku === "GHA-KYN-01");

  if (jollofItem) {
    await db.insert(menuItemModifiers).values([
      { menuItemId: jollofItem.id, modifierId: modProtein.id },
      { menuItemId: jollofItem.id, modifierId: modPepper.id },
      { menuItemId: jollofItem.id, modifierId: modSides.id },
    ]);
  }
  if (waakyeItem) {
    await db.insert(menuItemModifiers).values([
      { menuItemId: waakyeItem.id, modifierId: modProtein.id },
      { menuItemId: waakyeItem.id, modifierId: modPepper.id },
    ]);
  }
  if (tilapiaItem) {
    await db.insert(menuItemModifiers).values([
      { menuItemId: tilapiaItem.id, modifierId: modPepper.id },
      { menuItemId: tilapiaItem.id, modifierId: modSides.id },
    ]);
  }
  if (suyaItem) {
    await db.insert(menuItemModifiers).values([
      { menuItemId: suyaItem.id, modifierId: modPepper.id },
    ]);
  }

  // 8. Verified Food & Beverage Suppliers
  const [supMakola, supFish, supFarm, supMeat, supDrinks] = await db
    .insert(suppliers)
    .values([
      {
        name: "Makola Grains & Spices Wholesalers (Accra)",
        contactPerson: "Madam Faustina Mensah",
        email: "orders@makolagrains.gh",
        phone: "+233 24 330 9911",
        address: "Makola Market Block C, Central Accra",
        paymentTerms: "Net 15",
        leadTimeDays: 1,
      },
      {
        name: "Tema Fishing Harbour Seafood Depot",
        contactPerson: "Captain Nii Armah",
        email: "nii@temaseafood.gh",
        phone: "+233 20 882 1040",
        address: "Canoe Basin, Tema Harbour",
        paymentTerms: "Net 7",
        leadTimeDays: 1,
      },
      {
        name: "Agbogbloshie Fresh Produce Supply",
        contactPerson: "Opanin Kwadwo Antwi",
        email: "antwi@agbogbloshiefresh.gh",
        phone: "+233 55 901 3322",
        address: "Yam & Plantain Market, Agbogbloshie, Accra",
        paymentTerms: "Net 7",
        leadTimeDays: 1,
      },
      {
        name: "Ashaiman Livestock & Meat Processing Ltd.",
        contactPerson: "Alhaji Haruna Iddrisu",
        email: "sales@ashaimanmeat.gh",
        phone: "+233 24 551 7788",
        address: "Tulaku Meat Center, Ashaiman",
        paymentTerms: "Net 15",
        leadTimeDays: 1,
      },
      {
        name: "Accra Brewery Limited & Beverage Distributors",
        contactPerson: "Patricia Quaye",
        email: "patricia@abl-drinks.gh",
        phone: "+233 30 222 5500",
        address: "Graphic Road, South Industrial Area, Accra",
        paymentTerms: "Net 30",
        leadTimeDays: 2,
      },
    ])
    .returning();

  // 9. Raw Ingredients Master Records
  const ingList = await db
    .insert(ingredients)
    .values([
      {
        name: "Perfumed Jasmine Rice",
        sku: "ING-RICE-JASMIN",
        category: "dry_goods",
        currentStock: "120.000",
        minStockLevel: "30.000",
        unit: "kg",
        costPerUnit: "28.00",
        supplierId: supMakola.id,
        location: "Dry Store Grain Room",
      },
      {
        name: "Fresh Whole Volta Tilapia (Large)",
        sku: "ING-TILAPIA-WHL",
        category: "meat",
        currentStock: "35.000",
        minStockLevel: "12.000",
        unit: "pcs",
        costPerUnit: "38.00",
        supplierId: supFish.id,
        location: "Seafood Deep Freezer",
      },
      {
        name: "Fresh Goat Meat (Bone-in Cut)",
        sku: "ING-GOAT-BONEIN",
        category: "meat",
        currentStock: "45.000",
        minStockLevel: "15.000",
        unit: "kg",
        costPerUnit: "75.00",
        supplierId: supMeat.id,
        location: "Walk-in Meat Locker",
      },
      {
        name: "Prime Beef Chuck & Suya Cuts",
        sku: "ING-BEEF-SUYA",
        category: "meat",
        currentStock: "40.000",
        minStockLevel: "12.000",
        unit: "kg",
        costPerUnit: "70.00",
        supplierId: supMeat.id,
        location: "Walk-in Meat Locker",
      },
      {
        name: "Ripe Sweet Plantains",
        sku: "ING-PLANT-RIPE",
        category: "produce",
        currentStock: "80.000",
        minStockLevel: "25.000",
        unit: "kg",
        costPerUnit: "18.00",
        supplierId: supFarm.id,
        location: "Produce Storage Rack A",
      },
      {
        name: "Pona Yam Tubers",
        sku: "ING-YAM-PONA",
        category: "produce",
        currentStock: "65.000",
        minStockLevel: "20.000",
        unit: "kg",
        costPerUnit: "22.00",
        supplierId: supFarm.id,
        location: "Yam Cellar",
      },
      {
        name: "Fresh Cocoyam Leaves (Kontomire)",
        sku: "ING-KONTOMIRE",
        category: "produce",
        currentStock: "25.000",
        minStockLevel: "8.000",
        unit: "kg",
        costPerUnit: "15.00",
        supplierId: supFarm.id,
        location: "Vegetable Chiller",
      },
      {
        name: "Fermented Corn & Cassava Banku Dough",
        sku: "ING-BANKU-DOUGH",
        category: "produce",
        currentStock: "50.000",
        minStockLevel: "15.000",
        unit: "kg",
        costPerUnit: "12.00",
        supplierId: supFarm.id,
        location: "Cool Prep Retarder",
      },
      {
        name: "Black-Eyed Beans (Waakye Beans)",
        sku: "ING-BEANS-EYED",
        category: "dry_goods",
        currentStock: "60.000",
        minStockLevel: "20.000",
        unit: "kg",
        costPerUnit: "24.00",
        supplierId: supMakola.id,
        location: "Dry Store Grain Room",
      },
      {
        name: "Authentic Black Shito Chili Paste",
        sku: "ING-SHITO-PASTE",
        category: "dry_goods",
        currentStock: "18.000",
        minStockLevel: "5.000",
        unit: "kg",
        costPerUnit: "45.00",
        supplierId: supMakola.id,
        location: "Sauce & Spice Bay",
      },
      {
        name: "Zomi Spiced Red Palm Oil",
        sku: "ING-PALM-OIL",
        category: "dry_goods",
        currentStock: "30.000",
        minStockLevel: "10.000",
        unit: "liter",
        costPerUnit: "26.00",
        supplierId: supMakola.id,
        location: "Oil & Condiment Rack",
      },
      {
        name: "Dried Hibiscus / Sobolo Flowers",
        sku: "ING-SOBOLO-FLW",
        category: "dry_goods",
        currentStock: "15.000",
        minStockLevel: "4.000",
        unit: "kg",
        costPerUnit: "35.00",
        supplierId: supMakola.id,
        location: "Beverage Tea Rack",
      },
      {
        name: "Club Premium Lager Beer (625ml Bottles)",
        sku: "ING-CLUB-BEER",
        category: "beverage",
        currentStock: "96.000",
        minStockLevel: "24.000",
        unit: "bottle",
        costPerUnit: "14.00",
        supplierId: supDrinks.id,
        location: "Cold Beverage Cooler",
      },
    ])
    .returning();

  // 10. Link Verified Standard Recipes for Automated Stock Deductions
  const ingRice = ingList.find((i) => i.sku === "ING-RICE-JASMIN")!;
  const ingTilapia = ingList.find((i) => i.sku === "ING-TILAPIA-WHL")!;
  const ingBeef = ingList.find((i) => i.sku === "ING-BEEF-SUYA")!;
  const ingPlantain = ingList.find((i) => i.sku === "ING-PLANT-RIPE")!;
  const ingDough = ingList.find((i) => i.sku === "ING-BANKU-DOUGH")!;
  const ingBeans = ingList.find((i) => i.sku === "ING-BEANS-EYED")!;
  const ingShito = ingList.find((i) => i.sku === "ING-SHITO-PASTE")!;
  const ingSobolo = ingList.find((i) => i.sku === "ING-SOBOLO-FLW")!;

  // 1. Jollof Recipe
  if (jollofItem) {
    const [jollofRec] = await db
      .insert(recipes)
      .values({
        menuItemId: jollofItem.id,
        yieldCount: 1,
        prepInstructions: "Fry tomato paste, crushed ginger, garlic, onions, and scotch bonnet in vegetable oil until fragrant. Add seasoned stock and washed Jasmine rice. Steam slowly with parchment seal until bottom achieves golden smoky bottom pot flavor (kanzo). Garnish with sweet fried plantain.",
        totalRecipeCost: "22.00",
      })
      .returning();

    await db.insert(recipeIngredients).values([
      { recipeId: jollofRec.id, ingredientId: ingRice.id, quantity: "0.250", unit: "kg", costPortion: "7.00" },
      { recipeId: jollofRec.id, ingredientId: ingPlantain.id, quantity: "0.200", unit: "kg", costPortion: "3.60" },
      { recipeId: jollofRec.id, ingredientId: ingShito.id, quantity: "0.050", unit: "kg", costPortion: "2.25" },
    ]);
  }

  // 2. Waakye Recipe
  if (waakyeItem) {
    const [waakyeRec] = await db
      .insert(recipes)
      .values({
        menuItemId: waakyeItem.id,
        yieldCount: 1,
        prepInstructions: "Boil black-eyed beans with dried red waakye sorghum stalks for deep burgundy color. Add Jasmine rice and steam until fluffy. Serve with talia, gari foto, boiled egg, and spicy black shito.",
        totalRecipeCost: "26.00",
      })
      .returning();

    await db.insert(recipeIngredients).values([
      { recipeId: waakyeRec.id, ingredientId: ingRice.id, quantity: "0.200", unit: "kg", costPortion: "5.60" },
      { recipeId: waakyeRec.id, ingredientId: ingBeans.id, quantity: "0.150", unit: "kg", costPortion: "3.60" },
      { recipeId: waakyeRec.id, ingredientId: ingShito.id, quantity: "0.060", unit: "kg", costPortion: "2.70" },
    ]);
  }

  // 3. Tilapia with Banku Recipe
  if (tilapiaItem) {
    const [tilapiaRec] = await db
      .insert(recipes)
      .values({
        menuItemId: tilapiaItem.id,
        yieldCount: 1,
        prepInstructions: "Score fresh whole Tilapia and rub inside/out with crushed ginger, garlic, aniseed, and scotch bonnet marinade. Charcoal-grill over moderate heat for 18 min until skin is crisp and smoky. Serve with two hot banku balls and asanka pepper.",
        totalRecipeCost: "45.00",
      })
      .returning();

    await db.insert(recipeIngredients).values([
      { recipeId: tilapiaRec.id, ingredientId: ingTilapia.id, quantity: "1.000", unit: "pcs", costPortion: "38.00" },
      { recipeId: tilapiaRec.id, ingredientId: ingDough.id, quantity: "0.400", unit: "kg", costPortion: "4.80" },
    ]);
  }

  // 4. Suya Kebabs Recipe
  if (suyaItem) {
    const [suyaRec] = await db
      .insert(recipes)
      .values({
        menuItemId: suyaItem.id,
        yieldCount: 1,
        prepInstructions: "Thread thinly sliced beef onto skewers, brush with vegetable oil and dredge heavily in Northern Ghana kuli-kuli peanut spice blend. Grill over hot coals for 4 minutes per side.",
        totalRecipeCost: "18.00",
      })
      .returning();

    await db.insert(recipeIngredients).values([
      { recipeId: suyaRec.id, ingredientId: ingBeef.id, quantity: "0.220", unit: "kg", costPortion: "15.40" },
    ]);
  }

  // 5. Kelewele Recipe
  const keleweleItem = items.find((i) => i.sku === "GHA-KLW-01");
  if (keleweleItem) {
    const [keleweleRec] = await db
      .insert(recipes)
      .values({
        menuItemId: keleweleItem.id,
        yieldCount: 1,
        prepInstructions: "Dice ripe plantains into bite-sized cubes. Toss with paste of fresh ginger, cayenne pepper, ground cloves, calash nutmeg, and salt. Deep-fry at 360F until dark caramelized amber. Serve hot with roasted groundnuts.",
        totalRecipeCost: "8.50",
      })
      .returning();

    await db.insert(recipeIngredients).values([
      { recipeId: keleweleRec.id, ingredientId: ingPlantain.id, quantity: "0.350", unit: "kg", costPortion: "6.30" },
    ]);
  }

  // 6. Sobolo Drink Recipe
  const soboloItem = items.find((i) => i.sku === "GHA-SBL-01");
  if (soboloItem) {
    const [soboloRec] = await db
      .insert(recipes)
      .values({
        menuItemId: soboloItem.id,
        yieldCount: 1,
        prepInstructions: "Steep dried hibiscus calyces with crushed spicy ginger, grains of selim (hwentia), and whole cloves. Strain and sweeten with fresh pineapple juice and raw cane sugar. Chill over ice.",
        totalRecipeCost: "6.00",
      })
      .returning();

    await db.insert(recipeIngredients).values([
      { recipeId: soboloRec.id, ingredientId: ingSobolo.id, quantity: "0.080", unit: "kg", costPortion: "2.80" },
    ]);
  }

  // 11. Initial Production Audit Log
  await db.insert(auditLogs).values([
    {
      userId: adminUser.id,
      userName: adminUser.name,
      action: "production_system_initialized",
      entityType: "system",
      entityId: "SYS-INIT",
      details: "Asanka Royal Bistro & Lounge production database initialized with master restaurant, branch, table layout, menu catalogue, and Ghanaian recipe configurations. Ready for live operations.",
    },
  ]);

  // 12. Verified Production Settings
  await db.insert(applicationSettings).values([
    { key: "restaurant_name", value: "Asanka Royal Bistro & Lounge", description: "Display name on customer receipts and screens" },
    { key: "tax_rate", value: "15.00", description: "GRA Sales VAT rate percentage" },
    { key: "service_charge", value: "0.00", description: "Default dine-in service charge percentage" },
    { key: "currency_symbol", value: "GH₵", description: "Currency display symbol (Ghanaian Cedi)" },
    { key: "currency_code", value: "GHS", description: "Three-letter ISO currency code" },
    { key: "enable_kds_auto_refresh", value: "true", description: "Auto-refresh kitchen display every 5 seconds" },
    { key: "enable_offline_mode", value: "true", description: "Enable local offline order buffer for PWA" },
    { key: "thermal_printer_paper_width", value: "80mm", description: "Standard thermal POS receipt roll width (80mm)" },
    { key: "payment_momo_recording_enabled", value: "true", description: "Staff may manually record confirmed MoMo payments (no gateway connection)" },
    { key: "payment_gateway_enabled", value: "false", description: "No payment gateway is configured; cash and MoMo are recorded manually by staff" },
    {
      key: "room_service_charge",
      value: "30.00",
      description: "Flat GH₵30 room-service charge added only when food is delivered to and eaten in a hotel room. Edit in settings to change instantly.",
    },
    {
      key: "complimentary_breakfast_enabled",
      value: "true",
      description: "Allows staff to record a complimentary breakfast at GH₵0.00 for room guests",
    },
  ]);

  console.log("Clean production master data seeded successfully!");
  console.log("Master records: 1 restaurant, 1 branch, 6 staff roles, 14 tables (all available), 7 categories, 14 menu items with recipes, 13 raw ingredients, 5 verified suppliers.");
  console.log("Operational records: 0 orders, 0 payments, 0 shifts, 0 dummy purchase orders.");
}

// Auto-run if executed directly
if (require.main === module) {
  seed()
    .then(() => process.exit(0))
    .catch((err) => {
      console.error("Error seeding production database:", err);
      process.exit(1);
    });
}
