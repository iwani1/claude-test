import { NextResponse } from "next/server";
import { db } from "@/db";
import { menuItems, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";

export async function PUT(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const itemId = Number(id);
    const body = await req.json();

    const [updated] = await db
      .update(menuItems)
      .set({
        ...body,
        price: body.price ? String(body.price) : undefined,
        costPrice: body.costPrice ? String(body.costPrice) : undefined,
      })
      .where(eq(menuItems.id, itemId))
      .returning();

    await db.insert(auditLogs).values({
      action: "menu_item_updated",
      entityType: "menu",
      entityId: String(itemId),
      details: `Updated item "${updated.name}" details/availability`,
    });

    return NextResponse.json({ success: true, item: updated });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function DELETE(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const itemId = Number(id);

    await db
      .update(menuItems)
      .set({ isAvailable: false })
      .where(eq(menuItems.id, itemId));

    await db.insert(auditLogs).values({
      action: "menu_item_deactivated",
      entityType: "menu",
      entityId: String(itemId),
      details: `Deactivated menu item ID ${itemId}`,
    });

    return NextResponse.json({ success: true });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
