import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, kitchenTickets, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { deductStockForOrder } from "@/lib/inventory-deduction";

export async function POST(req: Request) {
  try {
    const { offlineOrders } = await req.json();

    if (!Array.isArray(offlineOrders) || offlineOrders.length === 0) {
      return NextResponse.json({ success: true, syncedCount: 0, message: "No offline orders to sync" });
    }

    const syncedOrders: any[] = [];
    const duplicateCount: number = 0;

    for (const offOrder of offlineOrders) {
      const idempotencyKey = offOrder.idempotencyKey || `OFFLINE-${offOrder.clientTimestamp || Date.now()}-${Math.random()}`;

      // Check for existing order with this idempotency key
      const [existing] = await db
        .select()
        .from(orders)
        .where(eq(orders.idempotencyKey, idempotencyKey))
        .limit(1);

      if (existing) {
        syncedOrders.push(existing);
        continue;
      }

      // Create order
      const orderNumber = `ORD-OFF-${Date.now().toString().slice(-4)}-${Math.floor(100 + Math.random() * 900)}`;

      const [newOrder] = await db
        .insert(orders)
        .values({
          orderNumber,
          branchId: offOrder.branchId || 1,
          tableId: offOrder.tableId ? Number(offOrder.tableId) : null,
          userId: offOrder.userId || 1,
          customerName: offOrder.customerName || "Walk-in Guest",
          orderType: offOrder.orderType || "takeaway",
          status: offOrder.status || "completed",
          subtotal: String(offOrder.subtotal || "0.00"),
          taxAmount: String(offOrder.taxAmount || "0.00"),
          serviceCharge: String(offOrder.serviceCharge || "0.00"),
          discountAmount: String(offOrder.discountAmount || "0.00"),
          tipAmount: String(offOrder.tipAmount || "0.00"),
          totalAmount: String(offOrder.totalAmount || "0.00"),
          paidAmount: String(offOrder.paidAmount || offOrder.totalAmount || "0.00"),
          paymentStatus: offOrder.paymentStatus || "paid",
          notes: `[Synced from Offline POS] ${offOrder.notes || ""}`,
          idempotencyKey,
          stockDeducted: false,
        })
        .returning();

      if (offOrder.items && Array.isArray(offOrder.items)) {
        for (const it of offOrder.items) {
          await db.insert(orderItems).values({
            orderId: newOrder.id,
            menuItemId: it.menuItemId,
            itemName: it.itemName,
            quantity: it.quantity,
            unitPrice: String(it.unitPrice),
            totalPrice: String(it.totalPrice),
            costPrice: String(it.costPrice || "0.00"),
            modifiers: it.modifiers || [],
            specialInstructions: it.specialInstructions || "",
            itemStatus: "served",
            station: it.station || "kitchen",
          });
        }

        // Deduct inventory
        await deductStockForOrder(
          newOrder.id,
          newOrder.orderNumber,
          offOrder.items.map((it: any) => ({ menuItemId: it.menuItemId, quantity: it.quantity })),
          offOrder.userId
        );
      }

      syncedOrders.push(newOrder);
    }

    await db.insert(auditLogs).values({
      action: "offline_orders_synced",
      entityType: "system",
      entityId: "SYNC-OFFLINE",
      details: `Batch synced ${syncedOrders.length} offline orders safely with idempotency verification.`,
    });

    return NextResponse.json({
      success: true,
      syncedCount: syncedOrders.length,
      duplicateCount,
      orders: syncedOrders,
    });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
