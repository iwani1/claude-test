import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, diningTables, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { reverseStockForOrder } from "@/lib/inventory-deduction";

export async function GET(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const orderId = Number(id);

    const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));

    return NextResponse.json({ order: { ...order, items } });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function PATCH(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    const { id } = await params;
    const orderId = Number(id);
    const body = await req.json();
    const { status, discountAmount, discountReason, tipAmount, notes, returnStockOnCancel } = body;

    const [existingOrder] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!existingOrder) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const updates: any = { updatedAt: new Date() };
    if (status !== undefined) updates.status = status;
    if (discountAmount !== undefined) updates.discountAmount = String(discountAmount);
    if (discountReason !== undefined) updates.discountReason = discountReason;
    if (tipAmount !== undefined) updates.tipAmount = String(tipAmount);
    if (notes !== undefined) updates.notes = notes;

    // Recalculate total if discount or tip changed
    if (discountAmount !== undefined || tipAmount !== undefined) {
      const sub = Number(existingOrder.subtotal);
      const tax = Number(existingOrder.taxAmount);
      const serv = Number(existingOrder.serviceCharge);
      const disc = discountAmount !== undefined ? Number(discountAmount) : Number(existingOrder.discountAmount);
      const tip = tipAmount !== undefined ? Number(tipAmount) : Number(existingOrder.tipAmount);
      updates.totalAmount = Math.max(0, sub + tax + serv - disc + tip).toFixed(2);
    }

    const [updatedOrder] = await db
      .update(orders)
      .set(updates)
      .where(eq(orders.id, orderId))
      .returning();

    // If order was cancelled and returnStock is requested, reverse the recipe deduction
    if (status === "cancelled" && returnStockOnCancel && existingOrder.stockDeducted) {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
      await reverseStockForOrder(
        orderId,
        existingOrder.orderNumber,
        items.map((i) => ({ menuItemId: i.menuItemId, quantity: i.quantity }))
      );
    }

    // Release table if cancelled or completed
    if ((status === "completed" || status === "cancelled") && existingOrder.tableId) {
      await db
        .update(diningTables)
        .set({ status: "cleaning", currentOrderId: null })
        .where(eq(diningTables.id, existingOrder.tableId));
    }

    await db.insert(auditLogs).values({
      action: "order_updated",
      entityType: "order",
      entityId: String(orderId),
      details: `Order ${existingOrder.orderNumber} updated. Status: ${status || existingOrder.status}`,
    });

    return NextResponse.json({ success: true, order: updatedOrder });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
