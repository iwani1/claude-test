import { NextResponse } from "next/server";
import { db } from "@/db";
import { orders, orderItems, refunds, auditLogs, users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { reverseStockForOrder } from "@/lib/inventory-deduction";
import { requireSession } from "@/lib/guard";

export async function POST(req: Request, { params }: { params: Promise<{ id: string }> }) {
  try {
    // A valid signed session is mandatory before any refund is considered.
    const guard = await requireSession();
    if (!guard.ok) return guard.response;

    const { id } = await params;
    const orderId = Number(id);
    const body = await req.json();
    const { amount, reason, managerPin, returnStock } = body;

    // Refunds ALWAYS require an explicit manager/owner PIN, even when the
    // signed-in user already holds elevated rights. This produces a
    // deliberate second-factor approval on every money-out transaction.
    if (!managerPin) {
      return NextResponse.json(
        { error: "Manager PIN authorization is required to issue a refund." },
        { status: 403 }
      );
    }

    const [manager] = await db
      .select()
      .from(users)
      .where(eq(users.pin, managerPin))
      .limit(1);

    if (!manager || !manager.isActive || !["super_admin", "manager"].includes(manager.role)) {
      await db.insert(auditLogs).values({
        userId: guard.user.id,
        userName: guard.user.name,
        action: "refund_authorization_failed",
        entityType: "order",
        entityId: String(orderId),
        details: `Invalid or unauthorized manager PIN supplied for refund on order #${orderId}`,
      });
      return NextResponse.json(
        { error: "Unauthorized: a valid manager or owner PIN is required for refunds." },
        { status: 403 }
      );
    }

    const [order] = await db.select().from(orders).where(eq(orders.id, orderId)).limit(1);
    if (!order) {
      return NextResponse.json({ error: "Order not found" }, { status: 404 });
    }

    const refundAmt = Number(amount || order.paidAmount);

    const [refundRecord] = await db
      .insert(refunds)
      .values({
        orderId,
        amount: refundAmt.toFixed(2),
        reason: reason || "Customer requested refund",
        authorizedBy: manager.id, // the manager whose PIN approved this refund
        stockReturned: returnStock ?? false,
      })
      .returning();

    await db
      .update(orders)
      .set({
        status: "refunded",
        paymentStatus: "refunded",
        updatedAt: new Date(),
      })
      .where(eq(orders.id, orderId));

    if (returnStock && order.stockDeducted) {
      const items = await db.select().from(orderItems).where(eq(orderItems.orderId, orderId));
      await reverseStockForOrder(
        orderId,
        order.orderNumber,
        items.map((i) => ({ menuItemId: i.menuItemId, quantity: i.quantity }))
      );
    }

    await db.insert(auditLogs).values({
      userId: guard.user.id,
      userName: guard.user.name,
      action: "order_refunded",
      entityType: "order",
      entityId: String(orderId),
      details:
        `Refunded $${refundAmt.toFixed(2)} on ${order.orderNumber}. ` +
        `Reason: ${reason || "N/A"}. Restocked: ${!!returnStock}. ` +
        `Requested by ${guard.user.name}, approved via PIN by ${manager.name}.`,
    });

    return NextResponse.json({ success: true, refund: refundRecord });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
