import { NextResponse } from "next/server";
import { db } from "@/db";
import {
  orders,
  orderItems,
  kitchenTickets,
  diningTables,
  auditLogs,
  menuItems,
  modifierOptions,
} from "@/db/schema";
import { eq, desc, inArray } from "drizzle-orm";
import { deductStockForOrder } from "@/lib/inventory-deduction";
import { requireSession } from "@/lib/guard";
import { loadBillingConfig, priceOrder, fromCents } from "@/lib/pricing";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const status = searchParams.get("status");
    const limit = Number(searchParams.get("limit") || 50);

    let query = db.select().from(orders).orderBy(desc(orders.createdAt)).limit(limit);
    const orderList = await query;

    // Filter if needed
    const filtered = status ? orderList.filter((o) => o.status === status) : orderList;

    // Fetch order items for each order
    const allOrderIds = filtered.map((o) => o.id);
    const items = allOrderIds.length > 0 ? await db.select().from(orderItems) : [];

    const populatedOrders = filtered.map((ord) => ({
      ...ord,
      items: items.filter((it) => it.orderId === ord.id),
    }));

    return NextResponse.json({ orders: populatedOrders });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const guard = await requireSession();
    if (!guard.ok) return guard.response;

    const body = await req.json();
    const {
      branchId,
      tableId,
      roomNumber,
      customerName,
      customerPhone,
      orderType,
      discountAmount,
      discountPercent,
      discountReason,
      tipAmount,
      notes,
      items,
      idempotencyKey,
      sendToKitchen,
      isComplimentary,
      complimentaryReason,
    } = body;

    // The owning cashier is taken from the verified session so an order can
    // never be attributed to another employee by tampering with the payload.
    const userId = guard.user.id;

    if (!items || items.length === 0) {
      return NextResponse.json({ error: "Order must contain at least one item" }, { status: 400 });
    }

    const normalizedOrderType = String(orderType || "dine_in").toLowerCase();
    const allowedOrderTypes = ["dine_in", "room_service", "takeaway", "delivery"];
    if (!allowedOrderTypes.includes(normalizedOrderType)) {
      return NextResponse.json({ error: "Choose Dine-in, Room Service, Takeaway, or Delivery." }, { status: 400 });
    }
    if (normalizedOrderType === "room_service" && !String(roomNumber || "").trim()) {
      return NextResponse.json({ error: "Room number is required for room-service orders." }, { status: 400 });
    }

    // ---------------------------------------------------------------------
    // Price the bill on the server. The client's own subtotal/tax/total are
    // deliberately ignored: the dine-in room charge is mandatory revenue and
    // VAT must be consistent, so neither can be set by the browser.
    // ---------------------------------------------------------------------
    const config = await loadBillingConfig();

    const wantsComp = isComplimentary === true || isComplimentary === "true";
    if (wantsComp && normalizedOrderType !== "room_service") {
      return NextResponse.json(
        { error: "Complimentary breakfast is available only for room-service orders." },
        { status: 400 }
      );
    }
    if (wantsComp && !config.compBreakfastEnabled) {
      return NextResponse.json(
        { error: "Complimentary breakfast is currently disabled in settings." },
        { status: 400 }
      );
    }

    // ---------------------------------------------------------------------
    // Resolve authoritative prices from the menu database.
    //
    // The browser's unitPrice is never trusted: a modified client could
    // otherwise understate the bill. Base prices come from menu_items and
    // modifier surcharges are validated against modifier_options, so the only
    // thing the client controls is WHICH items/options and HOW MANY.
    // ---------------------------------------------------------------------
    const requestedMenuIds = items
      .map((it: any) => Number(it.menuItemId))
      .filter((n: number) => Number.isFinite(n));
    if (requestedMenuIds.length !== items.length) {
      return NextResponse.json({ error: "Every order line needs a valid menu item." }, { status: 400 });
    }

    const dbMenuItems = await db
      .select()
      .from(menuItems)
      .where(inArray(menuItems.id, requestedMenuIds));

    // Collect every modifier option id the client claims was chosen.
    const requestedOptionIds = new Set<number>();
    for (const it of items) {
      for (const m of it.modifiers || []) {
        const optId = Number(m?.id);
        if (Number.isFinite(optId)) requestedOptionIds.add(optId);
      }
    }
    const dbOptions = requestedOptionIds.size
      ? await db
          .select()
          .from(modifierOptions)
          .where(inArray(modifierOptions.id, [...requestedOptionIds]))
      : [];
    const optionById = new Map(dbOptions.map((o) => [o.id, o]));

    interface ResolvedLine {
      menuItemId: number;
      itemName: string;
      quantity: number;
      basePriceCents: number;
      modifierCents: number;
      unitPriceCents: number;
      costPrice: string;
      station: string;
      modifiers: any[];
      specialInstructions: string;
    }

    const resolvedLines: ResolvedLine[] = items.map((it: any) => {
      const menuRow = dbMenuItems.find((m) => m.id === Number(it.menuItemId));
      if (!menuRow) {
        throw Object.assign(new Error(`Menu item ${it.menuItemId} no longer exists`), {
          statusCode: 400,
        });
      }

      // Modifier surcharges are taken from the database, not the payload.
      let modifierCents = 0;
      const verifiedMods: any[] = [];
      for (const m of it.modifiers || []) {
        const opt = optionById.get(Number(m?.id));
        if (!opt) continue; // ignore unknown/tampered option ids
        modifierCents += Math.round(Number(opt.priceDelta || 0) * 100);
        verifiedMods.push({
          id: opt.id,
          modifierId: opt.modifierId,
          name: opt.name,
          optionName: opt.name,
          priceDelta: opt.priceDelta,
        });
      }

      const qty = Math.max(0, Math.floor(Number(it.quantity) || 0));

      return {
        menuItemId: menuRow.id,
        itemName: menuRow.name,
        quantity: qty,
        basePriceCents: Math.round(Number(menuRow.price) * 100),
        modifierCents,
        unitPriceCents: Math.round(Number(menuRow.price) * 100) + modifierCents,
        costPrice: menuRow.costPrice || "0.00",
        station: menuRow.station || "kitchen",
        modifiers: verifiedMods,
        specialInstructions: String(it.specialInstructions || "").slice(0, 500),
      };
    });

    const invalidLine = resolvedLines.find((l) => l.quantity <= 0);
    if (invalidLine) {
      return NextResponse.json({ error: "Each order line needs a quantity of at least 1." }, { status: 400 });
    }

    const pricing = priceOrder({
      lines: resolvedLines.map((l) => ({
        unitPrice: fromCents(l.basePriceCents),
        modifierTotal: fromCents(l.modifierCents),
        quantity: l.quantity,
      })),
      orderType: normalizedOrderType,
      discountCents: Math.round(Number(discountAmount || 0) * 100),
      discountPercent: Number(discountPercent || 0),
      tipCents: Math.round(Number(tipAmount || 0) * 100),
      isComplimentary: wantsComp,
      config,
    });

    const subtotal = fromCents(pricing.subtotalCents);
    const taxAmount = fromCents(pricing.taxCents);
    const serviceCharge = "0.00";
    const roomCharge = fromCents(pricing.roomChargeCents);
    const totalAmount = fromCents(pricing.totalCents);

    // Prevent duplicate submission if idempotency key provided
    if (idempotencyKey) {
      const [existing] = await db
        .select()
        .from(orders)
        .where(eq(orders.idempotencyKey, idempotencyKey))
        .limit(1);

      if (existing) {
        return NextResponse.json({ success: true, order: existing, duplicate: true });
      }
    }

    // Generate unique order number
    const timestampStr = Date.now().toString().slice(-4);
    const randStr = Math.floor(100 + Math.random() * 900);
    const orderNumber = `ORD-${timestampStr}-${randStr}`;

    // A complimentary order has nothing to collect, so it is settled at once.
    // It is still fully tracked: stock is deducted and a docket is printed.
    const isComp = pricing.isComplimentary;

    const [newOrder] = await db
      .insert(orders)
      .values({
        orderNumber,
        branchId: branchId || 1,
        tableId: normalizedOrderType === "dine_in" && tableId ? Number(tableId) : null,
        roomNumber: normalizedOrderType === "room_service" ? String(roomNumber).trim().slice(0, 20) : null,
        userId: userId || 1,
        customerName: customerName || "Walk-in Guest",
        customerPhone: customerPhone || "",
        orderType: normalizedOrderType,
        status: sendToKitchen !== false ? "preparing" : "draft",
        subtotal,
        taxAmount,
        serviceCharge,
        roomCharge,
        discountAmount: fromCents(pricing.discountCents),
        discountReason: isComp
          ? complimentaryReason || "Complimentary breakfast"
          : discountReason || "",
        tipAmount: fromCents(pricing.tipCents),
        totalAmount,
        paidAmount: isComp ? totalAmount : "0.00",
        paymentStatus: isComp ? "paid" : "unpaid",
        isComplimentary: isComp,
        complimentaryReason: isComp ? complimentaryReason || "Complimentary breakfast" : null,
        compValue: fromCents(pricing.compValueCents),
        complimentaryApprovedBy: isComp ? userId : null,
        notes: notes || "",
        idempotencyKey: idempotencyKey || null,
        stockDeducted: false,
      })
      .returning();

    // Insert order items using the server-resolved prices. Line totals are
    // recomputed here so they always agree with the priced bill above.
    const createdItems = [];
    for (const line of resolvedLines) {
      const [insertedItem] = await db
        .insert(orderItems)
        .values({
          orderId: newOrder.id,
          menuItemId: line.menuItemId,
          itemName: line.itemName,
          quantity: line.quantity,
          unitPrice: fromCents(line.unitPriceCents),
          totalPrice: fromCents(line.unitPriceCents * line.quantity),
          costPrice: String(line.costPrice || "0.00"),
          modifiers: line.modifiers,
          specialInstructions: line.specialInstructions,
          itemStatus: "preparing",
          station: line.station || "kitchen",
        })
        .returning();
      createdItems.push(insertedItem);
    }

    // If dine-in, update table status to occupied
    if (normalizedOrderType === "dine_in" && tableId) {
      await db
        .update(diningTables)
        .set({
          status: "occupied",
          currentOrderId: newOrder.id,
        })
        .where(eq(diningTables.id, Number(tableId)));
    }

    // Create Kitchen Ticket if sendToKitchen
    if (sendToKitchen !== false) {
      const ticketItems = createdItems.map((ci) => ({
        id: ci.id,
        name: ci.itemName,
        qty: ci.quantity,
        modifiers: ci.modifiers,
        notes: ci.specialInstructions,
        station: ci.station,
      }));

      await db.insert(kitchenTickets).values({
        orderId: newOrder.id,
        ticketNumber: `K-${orderNumber.slice(-4)}`,
        station: "kitchen",
        status: "preparing",
        items: ticketItems,
        startedAt: new Date(),
      });
    }

    // Automatically trigger recipe-based ingredient deduction.
    // This runs for complimentary orders too: the food was genuinely consumed,
    // so stock must fall and the kitchen must still be told to cook it.
    await deductStockForOrder(
      newOrder.id,
      newOrder.orderNumber,
      resolvedLines.map((l) => ({ menuItemId: l.menuItemId, quantity: l.quantity })),
      userId
    );

    // Audit log — the operator is the signed-in employee, not the guest.
    // Complimentary orders get their own action so management can review
    // every GH₵0 bill as a distinct, searchable event.
    const chargeNote = isComp
      ? `COMPLIMENTARY (${complimentaryReason || "breakfast"}), retail value GH₵${fromCents(pricing.compValueCents)}`
      : pricing.roomChargeCents > 0
        ? `incl. GH₵${roomCharge} dine-in room charge`
        : "no room charge (not dine-in)";

    await db.insert(auditLogs).values({
      userId,
      userName: guard.user.name,
      action: isComp ? "complimentary_order_created" : "order_created",
      entityType: "order",
      entityId: String(newOrder.id),
      details:
        `Created order ${newOrder.orderNumber} (GH₵${newOrder.totalAmount}, ${resolvedLines.length} lines) ` +
        `for guest "${customerName || "Walk-in Guest"}" via ${orderType || "dine_in"} — ${chargeNote}`,
    });

    return NextResponse.json({
      success: true,
      order: {
        ...newOrder,
        items: createdItems,
      },
    });
  } catch (err: any) {
    // Validation failures thrown while resolving menu prices are client errors.
    if (err?.statusCode === 400) {
      return NextResponse.json({ error: err.message }, { status: 400 });
    }
    console.error("Order create error:", err);
    return NextResponse.json({ error: "Could not create the order. Please try again." }, { status: 500 });
  }
}
