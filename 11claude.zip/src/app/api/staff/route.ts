import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, auditLogs } from "@/db/schema";
import { hashPassword } from "@/lib/auth";
import { requirePermission } from "@/lib/guard";
import { asc, eq } from "drizzle-orm";

export async function GET() {
  try {
    const guard = await requirePermission("canManageStaff", "GET /api/staff");
    if (!guard.ok) return guard.response;

    const staffList = await db
      .select({
        id: users.id,
        restaurantId: users.restaurantId,
        branchId: users.branchId,
        name: users.name,
        email: users.email,
        role: users.role,
        pin: users.pin,
        phone: users.phone,
        avatarUrl: users.avatarUrl,
        isActive: users.isActive,
        lastLogin: users.lastLogin,
        createdAt: users.createdAt,
      })
      .from(users)
      .orderBy(asc(users.name));

    return NextResponse.json({ staff: staffList });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}

export async function POST(req: Request) {
  try {
    const guard = await requirePermission("canManageStaff", "POST /api/staff");
    if (!guard.ok) return guard.response;

    const body = await req.json();
    const { action } = body;

    if (action === "create_employee") {
      const { name, email, password, pin, role, phone, branchId } = body;

      if (!name || !email || !role) {
        return NextResponse.json({ error: "Name, email, and role are required" }, { status: 400 });
      }

      const passwordHash = hashPassword(password || "Admin123!");

      const [newUser] = await db
        .insert(users)
        .values({
          restaurantId: 1,
          branchId: branchId ? Number(branchId) : 1,
          name,
          email,
          passwordHash,
          pin: pin || "1234",
          role,
          phone: phone || "",
          isActive: true,
        })
        .returning({
          id: users.id,
          name: users.name,
          email: users.email,
          role: users.role,
          pin: users.pin,
          isActive: users.isActive,
        });

      await db.insert(auditLogs).values({
        action: "employee_created",
        entityType: "user",
        entityId: String(newUser.id),
        details: `Created new employee: ${newUser.name} with role ${newUser.role}`,
      });

      return NextResponse.json({ success: true, employee: newUser });
    }

    if (action === "toggle_active") {
      const { userId, isActive } = body;
      const [updated] = await db
        .update(users)
        .set({ isActive: !!isActive })
        .where(eq(users.id, Number(userId)))
        .returning();

      return NextResponse.json({ success: true, employee: updated });
    }

    if (action === "update_pin") {
      const { userId, pin } = body;
      await db
        .update(users)
        .set({ pin })
        .where(eq(users.id, Number(userId)));

      return NextResponse.json({ success: true, message: "PIN updated successfully" });
    }

    return NextResponse.json({ error: "Invalid action" }, { status: 400 });
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
