import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { createToken, hasTerminalAccess, TERMINAL_ACCESS_DENIED_MESSAGE, UserRole } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const { pin } = await req.json();

    if (!pin) {
      return NextResponse.json({ error: "PIN is required" }, { status: 400 });
    }

    const [user] = await db.select().from(users).where(eq(users.pin, pin)).limit(1);

    if (!user || !user.isActive) {
      return NextResponse.json({ error: "Invalid PIN code" }, { status: 401 });
    }

    // Kitchen staff have no terminal access - dockets are printed by FOH.
    if (!hasTerminalAccess(user.role as UserRole)) {
      return NextResponse.json({ error: TERMINAL_ACCESS_DENIED_MESSAGE }, { status: 403 });
    }

    const sessionPayload = {
      id: user.id,
      restaurantId: user.restaurantId,
      branchId: user.branchId,
      name: user.name,
      email: user.email,
      role: user.role as any,
      avatarUrl: user.avatarUrl,
    };

    const token = createToken(sessionPayload);

    await db.insert(auditLogs).values({
      userId: user.id,
      userName: user.name,
      action: "pos_quick_pin_switch",
      entityType: "user",
      entityId: String(user.id),
      details: `Switched active cashier to ${user.name} (${user.role}) via PIN`,
    });

    const res = NextResponse.json({ success: true, user: sessionPayload, token });
    res.cookies.set("pos_session", token, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7,
    });
    return res;
  } catch (err: any) {
    return NextResponse.json({ error: err.message }, { status: 500 });
  }
}
