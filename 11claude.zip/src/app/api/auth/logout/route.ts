import { NextResponse } from "next/server";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";
import { getSessionUser } from "@/lib/guard";

export async function POST() {
  try {
    const user = await getSessionUser();

    if (user) {
      await db.insert(auditLogs).values({
        userId: user.id,
        userName: user.name,
        action: "user_logout",
        entityType: "user",
        entityId: String(user.id),
        details: `${user.name} signed out of the POS terminal`,
      });
    }

    const res = NextResponse.json({ success: true });
    // Expire the session cookie immediately.
    res.cookies.set("pos_session", "", {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      maxAge: 0,
    });
    return res;
  } catch (err) {
    const message = err instanceof Error ? err.message : "Logout failed";
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
