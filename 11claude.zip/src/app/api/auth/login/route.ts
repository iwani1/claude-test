import { NextResponse } from "next/server";
import { db } from "@/db";
import { users, auditLogs } from "@/db/schema";
import { eq } from "drizzle-orm";
import { verifyPassword, createToken, hasTerminalAccess, TERMINAL_ACCESS_DENIED_MESSAGE, UserRole } from "@/lib/auth";

export async function POST(req: Request) {
  try {
    const body = await req.json();
    const { email, password, pin } = body;

    let user;

    if (pin) {
      // PIN-based fast login/switch
      const results = await db.select().from(users).where(eq(users.pin, pin)).limit(1);
      user = results[0];
    } else if (email && password) {
      const results = await db.select().from(users).where(eq(users.email, email)).limit(1);
      user = results[0];
      if (user && !verifyPassword(password, user.passwordHash)) {
        user = null;
      }
    }

    if (!user || !user.isActive) {
      return NextResponse.json({ error: "Invalid credentials or inactive account" }, { status: 401 });
    }

    // Kitchen staff work from printed dockets and are refused a session even
    // if their account is active. Server-side, so it cannot be bypassed by
    // calling the API directly.
    if (!hasTerminalAccess(user.role as UserRole)) {
      await db.insert(auditLogs).values({
        userId: user.id,
        userName: user.name,
        action: "terminal_access_denied",
        entityType: "user",
        entityId: String(user.id),
        details: `Kitchen role '${user.role}' attempted terminal sign-in and was refused (no application access)`,
      });
      return NextResponse.json({ error: TERMINAL_ACCESS_DENIED_MESSAGE }, { status: 403 });
    }

    // Update last login
    await db.update(users).set({ lastLogin: new Date() }).where(eq(users.id, user.id));

    // Audit log
    await db.insert(auditLogs).values({
      userId: user.id,
      userName: user.name,
      action: "user_login",
      entityType: "user",
      entityId: String(user.id),
      details: `User logged in with role ${user.role}`,
    });

    const sessionPayload = {
      id: user.id,
      restaurantId: user.restaurantId,
      branchId: user.branchId,
      name: user.name,
      email: user.email,
      role: user.role as any,
      avatarUrl: user.avatarUrl,
    };

    const token = createToken(sessionPayload);

    const response = NextResponse.json({
      success: true,
      user: sessionPayload,
      token,
    });

    response.cookies.set("pos_session", token, {
      httpOnly: true,
      path: "/",
      sameSite: "lax",
      maxAge: 60 * 60 * 24 * 7, // 7 days
    });

    return response;
  } catch (error: any) {
    console.error("Login error:", error);
    return NextResponse.json({ error: "Internal server error" }, { status: 500 });
  }
}
