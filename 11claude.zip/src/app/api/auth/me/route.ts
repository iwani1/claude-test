import { NextResponse } from "next/server";
import { db } from "@/db";
import { users } from "@/db/schema";
import { eq } from "drizzle-orm";
import { ROLE_PERMISSIONS, UserRole } from "@/lib/auth";
import { getSessionUser } from "@/lib/guard";

export async function GET() {
  try {
    const session = await getSessionUser();

    if (!session) {
      return NextResponse.json({ authenticated: false, user: null });
    }

    // Re-read the user from the database so deactivated accounts and
    // role changes take effect immediately on the next request rather
    // than persisting inside a stale signed cookie.
    const [fresh] = await db
      .select()
      .from(users)
      .where(eq(users.id, session.id))
      .limit(1);

    if (!fresh || !fresh.isActive) {
      const res = NextResponse.json({ authenticated: false, user: null });
      res.cookies.set("pos_session", "", { httpOnly: true, path: "/", maxAge: 0 });
      return res;
    }

    return NextResponse.json({
      authenticated: true,
      user: {
        id: fresh.id,
        restaurantId: fresh.restaurantId,
        branchId: fresh.branchId,
        name: fresh.name,
        email: fresh.email,
        role: fresh.role as UserRole,
        avatarUrl: fresh.avatarUrl,
      },
      permissions: ROLE_PERMISSIONS[fresh.role as UserRole],
    });
  } catch (err) {
    const message = err instanceof Error ? err.message : "Session lookup failed";
    return NextResponse.json({ authenticated: false, error: message }, { status: 500 });
  }
}
