"use client";

import React, { useState } from "react";
import {
  Server,
  Download,
  Copy,
  Check,
  FileCode,
  ShieldCheck,
  Terminal,
  BookOpen,
  Calendar,
  Layers,
  Database,
  ExternalLink,
  Smartphone,
} from "lucide-react";

export const DeploymentHub: React.FC = () => {
  const [activeTab, setActiveTab] = useState<"instructions" | "database" | "htaccess" | "manuals" | "commercial">("instructions");
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const htaccessContent = `# ========================================================
# GreenGeeks Apache Production .htaccess
# Asanka Royal Bistro & Lounge - Ghanaian Restaurant POS
# ========================================================

# 1. Enable Rewrite Engine & Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# 2. Prevent Direct Directory Browsing & Protect Sensitive Files
Options -Indexes
<FilesMatch "^(\.env|\.git|composer\.(json|lock)|package(-lock)?\.json|drizzle\.config\.json|\.htaccess|\.user\.ini)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# 3. Security Headers
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>

# 4. Route Next.js Node.js Reverse Proxy or Static App Router
# If deployed via GreenGeeks cPanel "Setup Node.js App" (Phusion Passenger):
RewriteCond %{REQUEST_FILENAME} !-f
RewriteCond %{REQUEST_FILENAME} !-d
RewriteRule ^(.*)$ http://127.0.0.1:3000/$1 [P,L]
`;

  const mysqlSchemaContent = `-- =====================================================================
-- GreenGeeks Production MySQL / MariaDB Full Database Schema
-- Restaurant: Asanka Royal Bistro & Lounge (Accra, Ghana)
-- Point of Sale (POS) & Inventory Management ERP
-- =====================================================================

SET FOREIGN_KEY_CHECKS = 0;

CREATE DATABASE IF NOT EXISTS \`asanka_pos\`
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE \`asanka_pos\`;

-- 1. Organization & Branches
DROP TABLE IF EXISTS \`branches\`;
DROP TABLE IF EXISTS \`restaurants\`;

CREATE TABLE \`restaurants\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`legal_name\` VARCHAR(255),
  \`currency\` VARCHAR(10) NOT NULL DEFAULT 'GHS',
  \`currency_symbol\` VARCHAR(10) NOT NULL DEFAULT 'GH₵',
  \`phone\` VARCHAR(50),
  \`email\` VARCHAR(100),
  \`address\` TEXT,
  \`tax_number\` VARCHAR(100),
  \`logo_url\` TEXT,
  \`receipt_header\` TEXT,
  \`receipt_footer\` TEXT,
  \`default_tax_rate\` DECIMAL(5,2) NOT NULL DEFAULT 15.00,
  \`default_service_charge\` DECIMAL(5,2) NOT NULL DEFAULT 0.00,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE \`branches\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`restaurant_id\` INT NOT NULL,
  \`name\` VARCHAR(255) NOT NULL,
  \`code\` VARCHAR(50) NOT NULL,
  \`address\` TEXT,
  \`phone\` VARCHAR(50),
  \`manager_name\` VARCHAR(255),
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_branches_restaurant\` (\`restaurant_id\`),
  FOREIGN KEY (\`restaurant_id\`) REFERENCES \`restaurants\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 2. Staff Accounts & Permissions
DROP TABLE IF EXISTS \`users\`;

CREATE TABLE \`users\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`restaurant_id\` INT NOT NULL,
  \`branch_id\` INT,
  \`name\` VARCHAR(255) NOT NULL,
  \`email\` VARCHAR(191) NOT NULL UNIQUE,
  \`password_hash\` VARCHAR(255) NOT NULL,
  \`pin\` VARCHAR(10),
  \`role\` ENUM('super_admin', 'manager', 'cashier', 'cook', 'inventory_officer', 'accountant') NOT NULL,
  \`avatar_url\` TEXT,
  \`phone\` VARCHAR(50),
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE,
  \`last_login\` TIMESTAMP NULL,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_users_pin\` (\`pin\`),
  INDEX \`idx_users_role\` (\`role\`),
  FOREIGN KEY (\`restaurant_id\`) REFERENCES \`restaurants\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`branch_id\`) REFERENCES \`branches\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 3. Register Shifts & Cash Reconciliations
DROP TABLE IF EXISTS \`shifts\`;

CREATE TABLE \`shifts\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`branch_id\` INT NOT NULL,
  \`user_id\` INT NOT NULL,
  \`opened_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`closed_at\` TIMESTAMP NULL,
  \`opening_cash\` DECIMAL(10,2) NOT NULL,
  \`expected_closing_cash\` DECIMAL(10,2),
  \`actual_closing_cash\` DECIMAL(10,2),
  \`cash_difference\` DECIMAL(10,2),
  \`total_sales\` DECIMAL(10,2) DEFAULT 0.00,
  \`total_cash_sales\` DECIMAL(10,2) DEFAULT 0.00,
  \`total_card_sales\` DECIMAL(10,2) DEFAULT 0.00,
  \`cash_payouts\` DECIMAL(10,2) DEFAULT 0.00,
  \`status\` VARCHAR(20) NOT NULL DEFAULT 'open',
  \`notes\` TEXT,
  \`reconciled_by\` INT,
  INDEX \`idx_shifts_status\` (\`status\`),
  FOREIGN KEY (\`branch_id\`) REFERENCES \`branches\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`reconciled_by\`) REFERENCES \`users\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB;

-- 4. Dining Floor Plan & Tables
DROP TABLE IF EXISTS \`dining_tables\`;
DROP TABLE IF EXISTS \`dining_areas\`;

CREATE TABLE \`dining_areas\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`branch_id\` INT NOT NULL,
  \`name\` VARCHAR(255) NOT NULL,
  \`sort_order\` INT DEFAULT 0,
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE,
  FOREIGN KEY (\`branch_id\`) REFERENCES \`branches\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`dining_tables\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`area_id\` INT NOT NULL,
  \`branch_id\` INT NOT NULL,
  \`table_number\` VARCHAR(50) NOT NULL,
  \`capacity\` INT NOT NULL DEFAULT 4,
  \`status\` VARCHAR(20) NOT NULL DEFAULT 'available',
  \`current_order_id\` INT NULL,
  \`pos_x\` INT DEFAULT 0,
  \`pos_y\` INT DEFAULT 0,
  \`shape\` VARCHAR(20) DEFAULT 'square',
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE,
  INDEX \`idx_tables_status\` (\`status\`),
  FOREIGN KEY (\`area_id\`) REFERENCES \`dining_areas\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`branch_id\`) REFERENCES \`branches\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 5. Menu Categories, Items & Modifiers
DROP TABLE IF EXISTS \`menu_item_modifiers\`;
DROP TABLE IF EXISTS \`modifier_options\`;
DROP TABLE IF EXISTS \`modifiers\`;
DROP TABLE IF EXISTS \`menu_items\`;
DROP TABLE IF EXISTS \`menu_categories\`;

CREATE TABLE \`menu_categories\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`branch_id\` INT,
  \`name\` VARCHAR(255) NOT NULL,
  \`slug\` VARCHAR(100) NOT NULL,
  \`icon\` VARCHAR(50),
  \`sort_order\` INT DEFAULT 0,
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE
) ENGINE=InnoDB;

CREATE TABLE \`menu_items\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`category_id\` INT NOT NULL,
  \`name\` VARCHAR(255) NOT NULL,
  \`description\` TEXT,
  \`sku\` VARCHAR(100),
  \`barcode\` VARCHAR(100),
  \`price\` DECIMAL(10,2) NOT NULL,
  \`cost_price\` DECIMAL(10,2) DEFAULT 0.00,
  \`image_url\` TEXT,
  \`prep_time_minutes\` INT DEFAULT 15,
  \`station\` VARCHAR(50) DEFAULT 'kitchen',
  \`is_available\` BOOLEAN NOT NULL DEFAULT TRUE,
  \`is_featured\` BOOLEAN DEFAULT FALSE,
  \`tax_rate\` DECIMAL(5,2) DEFAULT 15.00,
  \`has_recipe\` BOOLEAN DEFAULT FALSE,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_menu_items_category\` (\`category_id\`),
  FOREIGN KEY (\`category_id\`) REFERENCES \`menu_categories\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`modifiers\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`min_selection\` INT DEFAULT 0,
  \`max_selection\` INT DEFAULT 1,
  \`is_required\` BOOLEAN DEFAULT FALSE
) ENGINE=InnoDB;

CREATE TABLE \`modifier_options\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`modifier_id\` INT NOT NULL,
  \`name\` VARCHAR(255) NOT NULL,
  \`price_delta\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`sort_order\` INT DEFAULT 0,
  FOREIGN KEY (\`modifier_id\`) REFERENCES \`modifiers\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`menu_item_modifiers\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`menu_item_id\` INT NOT NULL,
  \`modifier_id\` INT NOT NULL,
  FOREIGN KEY (\`menu_item_id\`) REFERENCES \`menu_items\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`modifier_id\`) REFERENCES \`modifiers\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 6. Raw Ingredients, Recipes & Inventory
DROP TABLE IF EXISTS \`stock_counts\`;
DROP TABLE IF EXISTS \`stock_movements\`;
DROP TABLE IF EXISTS \`recipe_ingredients\`;
DROP TABLE IF EXISTS \`recipes\`;
DROP TABLE IF EXISTS \`ingredients\`;
DROP TABLE IF EXISTS \`suppliers\`;

CREATE TABLE \`suppliers\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`contact_person\` VARCHAR(255),
  \`email\` VARCHAR(100),
  \`phone\` VARCHAR(50),
  \`address\` TEXT,
  \`payment_terms\` VARCHAR(50) DEFAULT 'Net 15',
  \`lead_time_days\` INT DEFAULT 2,
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE \`ingredients\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`name\` VARCHAR(255) NOT NULL,
  \`sku\` VARCHAR(100) UNIQUE,
  \`category\` VARCHAR(50) DEFAULT 'general',
  \`current_stock\` DECIMAL(12,3) NOT NULL DEFAULT 0.000,
  \`min_stock_level\` DECIMAL(12,3) NOT NULL DEFAULT 10.000,
  \`unit\` VARCHAR(20) NOT NULL,
  \`cost_per_unit\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`supplier_id\` INT,
  \`location\` VARCHAR(100) DEFAULT 'Main Dry Storage',
  \`image_url\` TEXT,
  \`is_active\` BOOLEAN NOT NULL DEFAULT TRUE,
  \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`supplier_id\`) REFERENCES \`suppliers\`(\`id\`) ON DELETE SET NULL
) ENGINE=InnoDB;

CREATE TABLE \`recipes\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`menu_item_id\` INT NOT NULL UNIQUE,
  \`yield_count\` INT NOT NULL DEFAULT 1,
  \`prep_instructions\` TEXT,
  \`total_recipe_cost\` DECIMAL(10,2) DEFAULT 0.00,
  \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  FOREIGN KEY (\`menu_item_id\`) REFERENCES \`menu_items\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`recipe_ingredients\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`recipe_id\` INT NOT NULL,
  \`ingredient_id\` INT NOT NULL,
  \`quantity\` DECIMAL(12,3) NOT NULL,
  \`unit\` VARCHAR(20) NOT NULL,
  \`cost_portion\` DECIMAL(10,2) DEFAULT 0.00,
  FOREIGN KEY (\`recipe_id\`) REFERENCES \`recipes\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`ingredient_id\`) REFERENCES \`ingredients\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`stock_movements\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`ingredient_id\` INT NOT NULL,
  \`movement_type\` VARCHAR(50) NOT NULL,
  \`quantity_delta\` DECIMAL(12,3) NOT NULL,
  \`previous_stock\` DECIMAL(12,3) NOT NULL,
  \`new_stock\` DECIMAL(12,3) NOT NULL,
  \`reference_id\` VARCHAR(100),
  \`unit_cost\` DECIMAL(10,2),
  \`reason\` TEXT,
  \`created_by_id\` INT,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_stock_mov_ingredient\` (\`ingredient_id\`),
  FOREIGN KEY (\`ingredient_id\`) REFERENCES \`ingredients\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`stock_counts\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`count_date\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`conducted_by\` INT NOT NULL,
  \`notes\` TEXT,
  \`status\` VARCHAR(20) NOT NULL DEFAULT 'completed',
  \`items\` JSON NOT NULL,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (\`conducted_by\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 7. Purchase Orders & Goods Receipt Notes (GRN)
DROP TABLE IF EXISTS \`goods_receipts\`;
DROP TABLE IF EXISTS \`purchase_order_items\`;
DROP TABLE IF EXISTS \`purchase_orders\`;

CREATE TABLE \`purchase_orders\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`po_number\` VARCHAR(100) NOT NULL UNIQUE,
  \`supplier_id\` INT NOT NULL,
  \`branch_id\` INT NOT NULL,
  \`created_by_id\` INT NOT NULL,
  \`status\` VARCHAR(50) NOT NULL DEFAULT 'ordered',
  \`subtotal\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`tax\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`total\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`expected_delivery_date\` TIMESTAMP NULL,
  \`notes\` TEXT,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`received_at\` TIMESTAMP NULL,
  FOREIGN KEY (\`supplier_id\`) REFERENCES \`suppliers\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`branch_id\`) REFERENCES \`branches\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`created_by_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`purchase_order_items\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`purchase_order_id\` INT NOT NULL,
  \`ingredient_id\` INT NOT NULL,
  \`ordered_quantity\` DECIMAL(12,3) NOT NULL,
  \`received_quantity\` DECIMAL(12,3) DEFAULT 0.000,
  \`unit_price\` DECIMAL(10,2) NOT NULL,
  \`total_price\` DECIMAL(10,2) NOT NULL,
  \`unit\` VARCHAR(20) NOT NULL,
  FOREIGN KEY (\`purchase_order_id\`) REFERENCES \`purchase_orders\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`ingredient_id\`) REFERENCES \`ingredients\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`goods_receipts\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`grn_number\` VARCHAR(100) NOT NULL UNIQUE,
  \`purchase_order_id\` INT NOT NULL,
  \`received_by\` INT NOT NULL,
  \`invoice_number\` VARCHAR(100),
  \`received_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`notes\` TEXT,
  \`items_received\` JSON NOT NULL,
  FOREIGN KEY (\`purchase_order_id\`) REFERENCES \`purchase_orders\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`received_by\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 8. Orders, Order Items, Dockets & Settlements
DROP TABLE IF EXISTS \`refunds\`;
DROP TABLE IF EXISTS \`payments\`;
DROP TABLE IF EXISTS \`kitchen_tickets\`;
DROP TABLE IF EXISTS \`order_items\`;
DROP TABLE IF EXISTS \`orders\`;

CREATE TABLE \`orders\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`order_number\` VARCHAR(100) NOT NULL UNIQUE,
  \`branch_id\` INT NOT NULL,
  \`table_id\` INT NULL,
  \`room_number\` VARCHAR(50) NULL,
  \`user_id\` INT NOT NULL,
  \`customer_name\` VARCHAR(255) DEFAULT 'Walk-in Guest',
  \`customer_phone\` VARCHAR(50),
  \`order_type\` VARCHAR(50) NOT NULL DEFAULT 'dine_in',
  \`status\` VARCHAR(50) NOT NULL DEFAULT 'draft',
  \`subtotal\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`tax_amount\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`service_charge\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`room_charge\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`discount_amount\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`discount_reason\` TEXT,
  \`tip_amount\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`total_amount\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`paid_amount\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`payment_status\` VARCHAR(50) NOT NULL DEFAULT 'unpaid',
  \`is_complimentary\` BOOLEAN NOT NULL DEFAULT FALSE,
  \`complimentary_reason\` TEXT,
  \`comp_value\` DECIMAL(10,2) NOT NULL DEFAULT 0.00,
  \`complimentary_approved_by\` INT NULL,
  \`notes\` TEXT,
  \`idempotency_key\` VARCHAR(191) UNIQUE NULL,
  \`stock_deducted\` BOOLEAN NOT NULL DEFAULT FALSE,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  INDEX \`idx_orders_status\` (\`status\`),
  INDEX \`idx_orders_payment_status\` (\`payment_status\`),
  FOREIGN KEY (\`branch_id\`) REFERENCES \`branches\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`table_id\`) REFERENCES \`dining_tables\`(\`id\`) ON DELETE SET NULL,
  FOREIGN KEY (\`user_id\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`order_items\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`order_id\` INT NOT NULL,
  \`menu_item_id\` INT NOT NULL,
  \`item_name\` VARCHAR(255) NOT NULL,
  \`quantity\` INT NOT NULL,
  \`unit_price\` DECIMAL(10,2) NOT NULL,
  \`total_price\` DECIMAL(10,2) NOT NULL,
  \`cost_price\` DECIMAL(10,2) DEFAULT 0.00,
  \`modifiers\` JSON,
  \`special_instructions\` TEXT,
  \`item_status\` VARCHAR(50) NOT NULL DEFAULT 'pending',
  \`station\` VARCHAR(50) NOT NULL DEFAULT 'kitchen',
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_order_items_order\` (\`order_id\`),
  FOREIGN KEY (\`order_id\`) REFERENCES \`orders\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`menu_item_id\`) REFERENCES \`menu_items\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`kitchen_tickets\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`order_id\` INT NOT NULL,
  \`ticket_number\` VARCHAR(100) NOT NULL,
  \`station\` VARCHAR(50) NOT NULL DEFAULT 'kitchen',
  \`status\` VARCHAR(50) NOT NULL DEFAULT 'pending',
  \`items\` JSON NOT NULL,
  \`started_at\` TIMESTAMP NULL,
  \`ready_at\` TIMESTAMP NULL,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (\`order_id\`) REFERENCES \`orders\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`payments\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`order_id\` INT NOT NULL,
  \`amount\` DECIMAL(10,2) NOT NULL,
  \`payment_method\` VARCHAR(50) NOT NULL, -- 'cash' | 'momo'
  \`reference_number\` VARCHAR(100),
  \`cash_tendered\` DECIMAL(10,2),
  \`change_given\` DECIMAL(10,2),
  \`status\` VARCHAR(50) NOT NULL DEFAULT 'completed',
  \`processed_by\` INT NOT NULL,
  \`gateway_response\` JSON,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_payments_method\` (\`payment_method\`),
  FOREIGN KEY (\`order_id\`) REFERENCES \`orders\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`processed_by\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

CREATE TABLE \`refunds\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`order_id\` INT NOT NULL,
  \`payment_id\` INT,
  \`amount\` DECIMAL(10,2) NOT NULL,
  \`reason\` TEXT NOT NULL,
  \`authorized_by\` INT NOT NULL,
  \`stock_returned\` BOOLEAN NOT NULL DEFAULT FALSE,
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (\`order_id\`) REFERENCES \`orders\`(\`id\`) ON DELETE CASCADE,
  FOREIGN KEY (\`authorized_by\`) REFERENCES \`users\`(\`id\`) ON DELETE CASCADE
) ENGINE=InnoDB;

-- 9. Audit Logs & System Configuration
DROP TABLE IF EXISTS \`audit_logs\`;
DROP TABLE IF EXISTS \`application_settings\`;

CREATE TABLE \`audit_logs\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`user_id\` INT,
  \`user_name\` VARCHAR(255),
  \`action\` VARCHAR(100) NOT NULL,
  \`entity_type\` VARCHAR(50) NOT NULL,
  \`entity_id\` VARCHAR(100),
  \`details\` TEXT,
  \`ip_address\` VARCHAR(50),
  \`created_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX \`idx_audit_logs_action\` (\`action\`),
  INDEX \`idx_audit_logs_user\` (\`user_id\`)
) ENGINE=InnoDB;

CREATE TABLE \`application_settings\` (
  \`id\` INT AUTO_INCREMENT PRIMARY KEY,
  \`key\` VARCHAR(191) NOT NULL UNIQUE,
  \`value\` TEXT NOT NULL,
  \`description\` TEXT,
  \`updated_at\` TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB;

SET FOREIGN_KEY_CHECKS = 1;

-- Finished full MySQL / MariaDB schema initialization script
`;

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-950 overflow-hidden">
      {/* Header */}
      <div className="p-4 bg-neutral-900 border-b border-neutral-800 flex flex-col sm:flex-row gap-3 justify-between items-start sm:items-center">
        <div>
          <h2 className="text-base font-bold text-white flex items-center gap-2">
            <Server className="w-5 h-5 text-emerald-400" />
            <span>GreenGeeks Hosting Deployment & Operations Manual (Ghana)</span>
          </h2>
          <p className="text-xs text-neutral-400 mt-0.5">
            Production deployment files, MySQL DDL migration, Apache config, MTN MoMo guides, and Ghanaian Chop Bar SOPs
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span className="px-2.5 py-1 rounded-lg bg-emerald-500/20 text-emerald-400 text-xs font-semibold border border-emerald-500/40">
            GreenGeeks EcoSite Ready
          </span>
        </div>
      </div>

      {/* Tabs */}
      <div className="px-4 py-2.5 bg-neutral-900/60 border-b border-neutral-800 flex gap-2 overflow-x-auto custom-scrollbar">
        <button
          onClick={() => setActiveTab("instructions")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
            activeTab === "instructions" ? "bg-amber-500 text-black" : "bg-neutral-800 text-neutral-300"
          }`}
        >
          Deployment Steps
        </button>
        <button
          onClick={() => setActiveTab("database")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
            activeTab === "database" ? "bg-amber-500 text-black" : "bg-neutral-800 text-neutral-300"
          }`}
        >
          MySQL / MariaDB Schema DDL
        </button>
        <button
          onClick={() => setActiveTab("htaccess")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
            activeTab === "htaccess" ? "bg-amber-500 text-black" : "bg-neutral-800 text-neutral-300"
          }`}
        >
          Apache .htaccess & Proxy
        </button>
        <button
          onClick={() => setActiveTab("manuals")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
            activeTab === "manuals" ? "bg-amber-500 text-black" : "bg-neutral-800 text-neutral-300"
          }`}
        >
          Ghanaian Staff SOPs
        </button>
        <button
          onClick={() => setActiveTab("commercial")}
          className={`px-3 py-1.5 rounded-lg text-xs font-semibold whitespace-nowrap transition ${
            activeTab === "commercial" ? "bg-amber-500 text-black" : "bg-neutral-800 text-neutral-300"
          }`}
        >
          Commercial & MoMo Costs
        </button>
      </div>

      {/* Tab Content */}
      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
        {/* TAB 1: Instructions */}
        {activeTab === "instructions" && (
          <div className="max-w-4xl space-y-4">
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Terminal className="w-4 h-4 text-amber-500" />
                <span>Step-by-Step GreenGeeks Production Deployment for Ghana Operations</span>
              </h3>

              <div className="space-y-4 text-xs text-neutral-300 leading-relaxed">
                <div className="p-3.5 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <div className="font-bold text-amber-400">Step 1: cPanel Database Configuration</div>
                  <p>
                    Log into your GreenGeeks cPanel &rarr; <strong>MySQL Database Wizard</strong>. Create database <code>asanka_pos</code>, create a database user, generate a 24-character random password, and grant <strong>ALL PRIVILEGES</strong>.
                  </p>
                </div>

                <div className="p-3.5 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <div className="font-bold text-amber-400">Step 2: Setup Node.js App (or PHP API)</div>
                  <p>
                    In cPanel, click <strong>Setup Node.js App</strong> (provided via Phusion Passenger on GreenGeeks). Select Node.js 20 LTS or 22 LTS, set Application Root to <code>/home/username/asanka-pos</code>, and Application Startup file to <code>server.js</code>.
                  </p>
                </div>

                <div className="p-3.5 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <div className="font-bold text-amber-400">Step 3: Environment Configuration (.env)</div>
                  <p>
                    Create your production <code>.env</code> in the application root:
                  </p>
                  <pre className="p-2.5 bg-neutral-950 rounded-lg font-mono text-[11px] text-neutral-400 overflow-x-auto">
{`DATABASE_URL=postgresql://user:pass@127.0.0.1:5432/asanka_pos
# Or MySQL equivalent for Laravel / Node backend:
# DB_CONNECTION=mysql
# DB_HOST=127.0.0.1
# DB_DATABASE=asanka_pos
AUTH_SECRET=greengeeks_super_secure_sha256_key_9941
NEXT_PUBLIC_APP_NAME="Asanka Royal POS"
NEXT_PUBLIC_CURRENCY_SYMBOL="GH₵"
NEXT_PUBLIC_RESTAURANT_ID=1`}
                  </pre>
                </div>

                <div className="p-3.5 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <div className="font-bold text-amber-400">Step 4: Cron Jobs for Nightly Audits & GRA Invoicing Logs</div>
                  <p>
                    In cPanel &rarr; <strong>Cron Jobs</strong>, add daily midnight automated reconciliation:
                  </p>
                  <code className="p-2 bg-neutral-950 rounded-md font-mono text-emerald-400 block text-[11px]">
                    0 0 * * * /usr/local/bin/php /home/username/asanka-pos/artisan schedule:run &gt;&gt; /dev/null 2&gt;&1
                  </code>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 2: MySQL / MariaDB Schema */}
        {activeTab === "database" && (
          <div className="max-w-4xl space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs text-neutral-400">
                Execute in GreenGeeks <strong>phpMyAdmin</strong> or via SSH CLI:
              </span>
              <button
                onClick={() => copyToClipboard(mysqlSchemaContent, "mysql")}
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
              >
                {copiedKey === "mysql" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === "mysql" ? "Copied!" : "Copy DDL SQL"}</span>
              </button>
            </div>

            <pre className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl font-mono text-xs text-neutral-300 overflow-x-auto max-h-[65vh] leading-relaxed custom-scrollbar">
              {mysqlSchemaContent}
            </pre>
          </div>
        )}

        {/* TAB 3: .htaccess */}
        {activeTab === "htaccess" && (
          <div className="max-w-4xl space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-xs text-neutral-400">
                Place inside GreenGeeks <code>public_html/.htaccess</code>:
              </span>
              <button
                onClick={() => copyToClipboard(htaccessContent, "htaccess")}
                className="px-3 py-1.5 bg-neutral-800 hover:bg-neutral-700 text-neutral-200 rounded-lg text-xs font-semibold flex items-center gap-1.5 transition"
              >
                {copiedKey === "htaccess" ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === "htaccess" ? "Copied!" : "Copy .htaccess"}</span>
              </button>
            </div>

            <pre className="p-4 bg-neutral-900 border border-neutral-800 rounded-2xl font-mono text-xs text-neutral-300 overflow-x-auto max-h-[65vh] leading-relaxed custom-scrollbar">
              {htaccessContent}
            </pre>
          </div>
        )}

        {/* TAB 4: Ghanaian Staff Manuals */}
        {activeTab === "manuals" && (
          <div className="max-w-4xl space-y-4 text-xs text-neutral-300">
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <BookOpen className="w-4 h-4 text-amber-500" />
                <span>Ghanaian Restaurant Standard Operating Procedures (SOPs)</span>
              </h3>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="p-4 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <h4 className="font-bold text-amber-400 text-xs">Cashier & Front-of-House (Akosua S.)</h4>
                  <ul className="list-disc pl-4 space-y-1 text-neutral-400 text-[11px]">
                    <li>Login with 4-digit PIN (Default: 3333).</li>
                    <li>Verify register cash float at start of shift (GH₵1,200).</li>
                    <li>Select Dine-in Table or Takeaway order type.</li>
                    <li>Customize protein choice (Goat meat, Chicken, Red Snapper, Wele).</li>
                    <li>Specify pepper/shito preference (Extra hot black shito, green kpakpo).</li>
                    <li>Prompt customer for MTN MoMo or accept GH₵ cash notes.</li>
                  </ul>
                </div>

                <div className="p-4 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <h4 className="font-bold text-amber-400 text-xs">Executive Chef (Chef Kwabena)</h4>
                  <ul className="list-disc pl-4 space-y-1 text-neutral-400 text-[11px]">
                    <li>Monitor KDS station tickets (Kitchen, Grill, Palm Wine Bar).</li>
                    <li>Elapsed timer alerts red when tickets exceed 15 minutes.</li>
                    <li>Tap 'Start Prep' for Tilapia grilling / Fufu pounding.</li>
                    <li>Tap 'Mark Ready' to alert servers for prompt dispatch.</li>
                  </ul>
                </div>

                <div className="p-4 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <h4 className="font-bold text-amber-400 text-xs">Stock Controller (Yaw Osei)</h4>
                  <ul className="list-disc pl-4 space-y-1 text-neutral-400 text-[11px]">
                    <li>Monitor Jasmine rice, Tilapia, and red palm oil inventory.</li>
                    <li>Receive Makola / Agbogbloshie delivery: Open Purchasing &rarr; GRN.</li>
                    <li>Verify delivered weight/quantity to automatically increase stock.</li>
                    <li>Record vegetable spoilage in Adjust Stock modal.</li>
                  </ul>
                </div>

                <div className="p-4 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                  <h4 className="font-bold text-amber-400 text-xs">General Manager & Owner (Nana Kwame)</h4>
                  <ul className="list-disc pl-4 space-y-1 text-neutral-400 text-[11px]">
                    <li>Authorize refunds with Manager PIN (2222).</li>
                    <li>Audit shift closing cash reconciliations and MoMo ledger.</li>
                    <li>Export monthly GRA VAT and QuickBooks CSV reports.</li>
                    <li>Monitor live dine-in table turnover remotely from mobile.</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* TAB 5: Commercial & MoMo */}
        {activeTab === "commercial" && (
          <div className="max-w-4xl space-y-4 text-xs text-neutral-300">
            <div className="bg-neutral-900 border border-neutral-800 rounded-2xl p-5 shadow-xl space-y-4">
              <h3 className="text-sm font-bold text-white flex items-center gap-2">
                <Calendar className="w-4 h-4 text-emerald-400" />
                <span>Ghanaian Commercial Infrastructure & Fee Estimates</span>
              </h3>

              <div className="p-4 bg-neutral-850 rounded-xl border border-neutral-800 space-y-2">
                <div className="font-bold text-white">Estimated Monthly Infrastructure & Gateway Costs</div>
                <div className="grid grid-cols-2 sm:grid-cols-3 gap-3 pt-2 font-mono text-[11px]">
                  <div className="p-2 bg-neutral-900 rounded-lg">
                    <span className="text-neutral-500 block">GreenGeeks Hosting</span>
                    <span className="text-emerald-400 font-bold">~GH₵160 / mo ($10.95)</span>
                  </div>
                  <div className="p-2 bg-neutral-900 rounded-lg">
                    <span className="text-neutral-500 block">MTN MoMo Interchange</span>
                    <span className="text-amber-400 font-bold">0.75% - 1.0%</span>
                  </div>
                  <div className="p-2 bg-neutral-900 rounded-lg">
                    <span className="text-neutral-500 block">Paystack Ghana</span>
                    <span className="text-white font-bold">1.95% local</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
