import crypto from "crypto";

export type UserRole =
  | "super_admin"
  | "manager"
  | "cashier"
  | "cook"
  | "inventory_officer"
  | "accountant";

export interface SessionUser {
  id: number;
  restaurantId: number;
  branchId: number | null;
  name: string;
  email: string;
  role: UserRole;
  avatarUrl?: string | null;
}

// Password hashing using Node.js crypto (PBKDF2)
export function hashPassword(password: string): string {
  const salt = crypto.randomBytes(16).toString("hex");
  const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex");
  return `${salt}:${hash}`;
}

export function verifyPassword(password: string, storedHash: string): boolean {
  try {
    const [salt, key] = storedHash.split(":");
    if (!salt || !key) return false;
    const hash = crypto.pbkdf2Sync(password, salt, 10000, 64, "sha512").toString("hex");
    return crypto.timingSafeEqual(Buffer.from(hash), Buffer.from(key));
  } catch {
    return false;
  }
}

// Simple signed token for browser sessions (stateless & greengeeks-friendly)
const SECRET = process.env.AUTH_SECRET || "pos_system_secret_greengeeks_key_2025_prod";

export function createToken(payload: SessionUser): string {
  const data = Buffer.from(JSON.stringify(payload)).toString("base64url");
  const signature = crypto.createHmac("sha256", SECRET).update(data).digest("base64url");
  return `${data}.${signature}`;
}

export function verifyToken(token: string): SessionUser | null {
  try {
    const [data, signature] = token.split(".");
    if (!data || !signature) return null;
    const expected = crypto.createHmac("sha256", SECRET).update(data).digest("base64url");
    if (signature !== expected) return null;
    return JSON.parse(Buffer.from(data, "base64url").toString());
  } catch {
    return null;
  }
}

// Permissions Matrix
export const ROLE_PERMISSIONS: Record<UserRole, {
  label: string;
  /** Whether this role may sign in to a POS terminal at all. Kitchen staff
   *  work from printed dockets and have no application access. */
  terminalAccess: boolean;
  canViewReports: boolean;
  canModifyInventory: boolean;
  canManageStaff: boolean;
  canIssueRefunds: boolean;
  canAccessPos: boolean;
  canAccessKds: boolean;
  canManageMenu: boolean;
  canManageSettings: boolean;
}> = {
  super_admin: {
    label: "Super Admin / Owner",
    terminalAccess: true,
    canViewReports: true,
    canModifyInventory: true,
    canManageStaff: true,
    canIssueRefunds: true,
    canAccessPos: true,
    canAccessKds: true,
    canManageMenu: true,
    canManageSettings: true,
  },
  manager: {
    label: "Restaurant Manager",
    terminalAccess: true,
    canViewReports: true,
    canModifyInventory: true,
    canManageStaff: true,
    canIssueRefunds: true,
    canAccessPos: true,
    canAccessKds: true,
    canManageMenu: true,
    canManageSettings: false,
  },
  cashier: {
    label: "Cashier / Front-of-House",
    terminalAccess: true,
    canViewReports: false,
    canModifyInventory: false,
    canManageStaff: false,
    canIssueRefunds: false, // requires manager approval
    canAccessPos: true,
    // Front-of-house prints and delivers dockets, so they coordinate progress.
    canAccessKds: true,
    canManageMenu: false,
    canManageSettings: false,
  },
  cook: {
    label: "Kitchen Staff (No Terminal Access)",
    // The kitchen works purely from printed dockets - no application login.
    terminalAccess: false,
    canViewReports: false,
    canModifyInventory: false,
    canManageStaff: false,
    canIssueRefunds: false,
    canAccessPos: false,
    canAccessKds: false,
    canManageMenu: false,
    canManageSettings: false,
  },
  inventory_officer: {
    label: "Inventory Officer",
    terminalAccess: true,
    canViewReports: true,
    canModifyInventory: true,
    canManageStaff: false,
    canIssueRefunds: false,
    canAccessPos: false,
    canAccessKds: false,
    canManageMenu: true,
    canManageSettings: false,
  },
  accountant: {
    terminalAccess: true,
    label: "Accountant / Finance",
    canViewReports: true,
    canModifyInventory: false,
    canManageStaff: false,
    canIssueRefunds: false,
    canAccessPos: false,
    canAccessKds: false,
    canManageMenu: false,
    canManageSettings: false,
  },
};

/**
 * Message shown when a role without terminal access attempts to sign in.
 * Kept next to the permission matrix so the wording and the gate stay aligned.
 */
export const TERMINAL_ACCESS_DENIED_MESSAGE =
  "Kitchen staff do not sign in to this terminal. Kitchen orders are printed as paper dockets and delivered to the kitchen by front-of-house staff.";

/** True when the role is permitted to open an application session. */
export function hasTerminalAccess(role: UserRole): boolean {
  return ROLE_PERMISSIONS[role]?.terminalAccess === true;
}
