"use client";

const OFFLINE_QUEUE_KEY = "bistro_pos_offline_orders_queue";
const MENU_CACHE_KEY = "bistro_pos_cached_menu";

export interface OfflineOrder {
  idempotencyKey: string;
  clientTimestamp: number;
  branchId: number;
  tableId: number | null;
  userId: number;
  customerName: string;
  orderType: string;
  items: any[];
  subtotal: number;
  taxAmount: number;
  serviceCharge: number;
  discountAmount: number;
  tipAmount: number;
  totalAmount: number;
  paidAmount: number;
  paymentMethod: string;
  paymentStatus: string;
  notes?: string;
}

export function saveMenuToCache(menuData: any) {
  if (typeof window === "undefined") return;
  try {
    localStorage.setItem(MENU_CACHE_KEY, JSON.stringify(menuData));
  } catch (e) {
    console.warn("Failed to cache menu:", e);
  }
}

export function getCachedMenu() {
  if (typeof window === "undefined") return null;
  try {
    const raw = localStorage.getItem(MENU_CACHE_KEY);
    return raw ? JSON.parse(raw) : null;
  } catch (e) {
    return null;
  }
}

export function queueOfflineOrder(order: OfflineOrder) {
  if (typeof window === "undefined") return;
  try {
    const queue = getOfflineQueue();
    queue.push(order);
    localStorage.setItem(OFFLINE_QUEUE_KEY, JSON.stringify(queue));
  } catch (e) {
    console.error("Failed to queue offline order:", e);
  }
}

export function getOfflineQueue(): OfflineOrder[] {
  if (typeof window === "undefined") return [];
  try {
    const raw = localStorage.getItem(OFFLINE_QUEUE_KEY);
    return raw ? JSON.parse(raw) : [];
  } catch (e) {
    return [];
  }
}

export function clearOfflineQueue() {
  if (typeof window === "undefined") return;
  localStorage.removeItem(OFFLINE_QUEUE_KEY);
}

export async function syncOfflineQueueToServer(): Promise<{ success: boolean; count: number }> {
  const queue = getOfflineQueue();
  if (queue.length === 0) return { success: true, count: 0 };

  try {
    const res = await fetch("/api/sync/offline", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ offlineOrders: queue }),
    });

    const data = await res.json();
    if (data.success) {
      clearOfflineQueue();
      return { success: true, count: data.syncedCount || queue.length };
    }
    return { success: false, count: 0 };
  } catch (e) {
    return { success: false, count: 0 };
  }
}
