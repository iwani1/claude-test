import { cookies } from "next/headers";
import { NextResponse } from "next/server";
import { verifyToken, ROLE_PERMISSIONS, SessionUser, UserRole } from "./auth";
import { db } from "@/db";
import { auditLogs } from "@/db/schema";

export type Permission = keyof (typeof ROLE_PERMISSIONS)["super_admin"];

/**
 * Reads and verifies the signed session cookie.
 * Returns null when no valid session is present.
 */
export async function getSessionUser(): Promise<SessionUser | null> {
  try {
    const cookieStore = await cookies();
    const token = cookieStore.get("pos_session")?.value;
    if (!token) return null;
    return verifyToken(token);
  } catch {
    return null;
  }
}

export interface GuardFailure {
  ok: false;
  response: NextResponse;
}

export interface GuardSuccess {
  ok: true;
  user: SessionUser;
}

/**
 * Enforces that the caller holds a valid session AND the named permission.
 * Denied attempts are written to the audit log so unauthorized access
 * attempts are traceable, per the security requirements.
 */
export async function requirePermission(
  permission: Permission,
  context: string
): Promise<GuardSuccess | GuardFailure> {
  const user = await getSessionUser();

  if (!user) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "Authentication required. Please sign in." },
        { status: 401 }
      ),
    };
  }

  const perms = ROLE_PERMISSIONS[user.role as UserRole];
  const granted = perms ? perms[permission] : false;

  if (!granted) {
    // Record the denied attempt for the audit trail.
    try {
      await db.insert(auditLogs).values({
        userId: user.id,
        userName: user.name,
        action: "authorization_denied",
        entityType: "system",
        entityId: context,
        details: `Role '${user.role}' was denied '${permission}' on ${context}`,
      });
    } catch {
      // Never let audit logging break the guard response.
    }

    return {
      ok: false,
      response: NextResponse.json(
        {
          error: `Access denied. Your role (${perms?.label ?? user.role}) is not permitted to perform this action.`,
        },
        { status: 403 }
      ),
    };
  }

  return { ok: true, user };
}

/**
 * Lightweight variant that only requires a valid signed session.
 */
export async function requireSession(): Promise<GuardSuccess | GuardFailure> {
  const user = await getSessionUser();
  if (!user) {
    return {
      ok: false,
      response: NextResponse.json(
        { error: "Authentication required. Please sign in." },
        { status: 401 }
      ),
    };
  }
  return { ok: true, user };
}
