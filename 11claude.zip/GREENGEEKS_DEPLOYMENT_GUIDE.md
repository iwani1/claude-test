# GreenGeeks Production Deployment Guide
## Asanka Royal Bistro & Lounge — Ghanaian Restaurant POS & Inventory ERP

This guide provides step-by-step instructions for deploying this application to your **GreenGeeks** hosting account.

---

### System Architecture Overview
- **Frontend / Fullstack:** Next.js (App Router), React 19, Tailwind CSS.
- **Backend APIs:** Next.js Route Handlers (`/api/*`) with granular RBAC authorization.
- **Database:** MySQL / MariaDB (via GreenGeeks cPanel MySQL Database Wizard) or PostgreSQL.
- **Tender Types:** Cash (GH₵) & Mobile Money (MoMo - MTN, Telecel, AT) with Split Tender support.
- **Kitchen Flow:** Front-of-house thermal docket printing (cooks operate without screens).

---

### Step 1: Create Production MySQL Database in cPanel
1. Log in to your **GreenGeeks cPanel**.
2. Under the **Databases** section, click **MySQL Database Wizard**.
3. **Step 1:** Enter database name (e.g., `cpaneluser_asankapos`).
4. **Step 2:** Create a database user (e.g., `cpaneluser_posadmin`) and generate a strong 24+ character password. **Save this password securely.**
5. **Step 3:** Assign user to database and check **ALL PRIVILEGES**. Click **Make Changes**.
6. Import Schema:
   - In cPanel, click **phpMyAdmin**.
   - Select your newly created database `cpaneluser_asankapos`.
   - Click the **Import** tab.
   - Upload the included `greengeeks_mysql_schema.sql` file and click **Go**.
   - Verify that all 25 tables are created without errors.

---

### Step 2: Configure Node.js Application in GreenGeeks cPanel
1. In cPanel, under **Software**, click **Setup Node.js App** (powered by Phusion Passenger).
2. Click **Create Application**:
   - **Node.js version:** Select `20.x` or `22.x` (LTS recommended).
   - **Application mode:** `Production`.
   - **Application root:** `/home/cpaneluser/asanka-pos` (or your chosen path).
   - **Application URL:** Select your domain or subdomain (e.g., `pos.asankaroyal.com`).
   - **Application startup file:** `server.js` (or leave blank if using default entry).
3. Click **Create**.
4. The cPanel interface will display a command to enter the virtual environment via SSH:
   ```bash
   source /home/cpaneluser/nodevenv/asanka-pos/20/bin/activate && cd /home/cpaneluser/asanka-pos
   ```

---

### Step 3: Upload Application Files
You can upload the project files via Git, SSH, or cPanel File Manager:
- Ensure the following files and folders are present:
  - `src/`
  - `public/`
  - `package.json`
  - `package-lock.json`
  - `next.config.ts`
  - `tsconfig.json`
  - `postcss.config.mjs`
  - `eslint.config.mjs`
  - `.env` (configured in Step 4)

---

### Step 4: Configure Production Environment (`.env`)
Create a `.env` file in your application root (`/home/cpaneluser/asanka-pos/.env`):
```env
# Database connection
DATABASE_URL="mysql://cpaneluser_posadmin:YourStrongPassword@localhost:3306/cpaneluser_asankapos"

# Production signed session secret (generate with `openssl rand -hex 32`)
AUTH_SECRET="your-64-character-random-hex-secret-key-here"

# Application settings
NODE_ENV="production"
PORT=3000
NEXT_PUBLIC_APP_NAME="Asanka Royal POS"
NEXT_PUBLIC_CURRENCY_SYMBOL="GH₵"
NEXT_PUBLIC_RESTAURANT_ID=1
```

*Note: Ensure file permissions on `.env` are set to `0600` so it is protected from unauthorized reading.*

---

### Step 5: Configure Apache `.htaccess`
Ensure the file `.htaccess` in your domain's `public_html` directory has the following rules:

```apache
# Force HTTPS
RewriteEngine On
RewriteCond %{HTTPS} off
RewriteRule ^(.*)$ https://%{HTTP_HOST}%{REQUEST_URI} [L,R=301]

# Protect Sensitive Configuration Files
Options -Indexes
<FilesMatch "^(\.env|\.git|package(-lock)?\.json|tsconfig\.json|\.htaccess)$">
    Order allow,deny
    Deny from all
</FilesMatch>

# Security Headers
<IfModule mod_headers.c>
    Header set X-Content-Type-Options "nosniff"
    Header set X-Frame-Options "SAMEORIGIN"
    Header set X-XSS-Protection "1; mode=block"
    Header set Referrer-Policy "strict-origin-when-cross-origin"
</IfModule>
```

---

### Step 6: Install Dependencies & Run Production Build
Run the following commands in SSH inside your application directory:
```bash
# 1. Enter virtual environment
source /home/cpaneluser/nodevenv/asanka-pos/20/bin/activate && cd /home/cpaneluser/asanka-pos

# 2. Install production dependencies
npm install --omit=dev

# 3. Build Next.js production bundle
npm run build

# 4. In cPanel Setup Node.js App, click 'Restart Application'
```

---

### Step 7: Configure Nightly Maintenance Cron Job
In cPanel, click **Cron Jobs**:
- Set frequency to **Once a day at midnight (0 0 * * *)**.
- Command:
  ```bash
  /usr/local/bin/curl -s -X POST https://pos.asankaroyal.com/api/sync/offline > /dev/null 2>&1
  ```

---

### Step 8: Production Go-Live Checklist
- [ ] Log in with the initial Super Admin account (`admin@asankaroyal.com` / PIN `1111`).
- [ ] Go to **Staff & Permissions** and change default PINs for all staff.
- [ ] Go to **Store Settings** and verify restaurant phone, email, and GRA TIN.
- [ ] Open the first register shift in **Cash Drawer** with the verified starting float (e.g. GH₵1,200).
- [ ] Verify that kitchen thermal docket printer is paired in the browser print dialog.
- [ ] Execute test order and verify kitchen docket printing and Cash/MoMo settlement.
