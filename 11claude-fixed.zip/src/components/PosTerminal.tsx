"use client";

import React, { useState, useMemo, useEffect } from "react";
import {
  Search,
  Plus,
  Minus,
  Trash2,
  DollarSign,
  Percent,
  ChefHat,
  Receipt,
  User,
  Phone,
  CheckCircle2,
  Coffee,
  X,
  Smartphone,
  Printer,
  Coins,
} from "lucide-react";
import { ReceiptModal } from "./ReceiptModal";
import { KitchenTicketModal } from "./KitchenTicketModal";
import { queueOfflineOrder } from "@/lib/offline-storage";
import { priceOrder, fromCents, toCents } from "@/lib/pricing-core";
import type { BillingConfig } from "@/lib/pricing-core";

interface PosTerminalProps {
  categories: any[];
  menuItems: any[];
  tables: any[];
  currentUser: any;
  onOrderCreated?: () => void;
  activeTableId?: number | null;
  resetKey?: number;
  onOpenDrawer?: () => void;
  onGoTables?: () => void;
  onGoOrders?: () => void;
}

export const PosTerminal: React.FC<PosTerminalProps> = ({
  categories,
  menuItems,
  tables,
  currentUser,
  onOrderCreated,
  activeTableId = null,
  resetKey = 0,
  onOpenDrawer,
  onGoTables,
  onGoOrders,
}) => {
  // State
  const [selectedCategory, setSelectedCategory] = useState<number | "all">("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [cart, setCart] = useState<any[]>([]);
  const [orderType, setOrderType] = useState<"dine_in" | "room_service" | "takeaway" | "delivery">("dine_in");
  const [selectedTableId, setSelectedTableId] = useState<number | null>(activeTableId);
  const [roomNumber, setRoomNumber] = useState("");
  const [customerName, setCustomerName] = useState("Walk-in Guest");
  const [customerPhone, setCustomerPhone] = useState("");
  const [orderNotes, setOrderNotes] = useState("");

  // Modals
  const [selectedItemForMod, setSelectedItemForMod] = useState<any | null>(null);
  const [itemModSelections, setItemModSelections] = useState<Record<string, any>>({});
  const [itemSpecialNotes, setItemSpecialNotes] = useState("");

  // Discount & Tip
  const [discountPercent, setDiscountPercent] = useState<number>(0);
  const [discountAmount, setDiscountAmount] = useState<number>(0);
  const [discountReason, setDiscountReason] = useState("");
  const [showDiscountModal, setShowDiscountModal] = useState(false);
  const [tipAmount, setTipAmount] = useState<number>(0);

  // Payment: Staff indicates Cash, MoMo, or Split (Both)
  const [showPayModal, setShowPayModal] = useState(false);
  const [paymentMethod, setPaymentMethod] = useState<"momo" | "cash" | "split">("momo");
  const [momoRef, setMomoRef] = useState<string>("");
  const [cashTendered, setCashTendered] = useState<string>("");
  const [splitCashAmount, setSplitCashAmount] = useState<string>("");
  const [splitMomoAmount, setSplitMomoAmount] = useState<string>("");
  const [splitCashTendered, setSplitCashTendered] = useState<string>("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  // Live billing rules (dine-in room charge + VAT) loaded from the server so
  // the total shown on the till matches what the API will actually charge.
  const [billingConfig, setBillingConfig] = useState<BillingConfig>({
    roomChargeCents: 3000, // GH₵30.00 default until the server responds
    taxRatePercent: 15,
    compBreakfastEnabled: true,
  });

  // Complimentary breakfast: a room guest eats free. Stock is still deducted
  // and the kitchen still gets a docket, but nothing is charged.
  const [isComplimentary, setIsComplimentary] = useState(false);
  const [compReason, setCompReason] = useState("Complimentary breakfast — room guest");
  const [showCompModal, setShowCompModal] = useState(false);

  // Keep local table selection in sync when opened from the floor plan,
  // and clear the ticket when the global "New Order" button is tapped.
  useEffect(() => {
    setSelectedTableId(activeTableId ?? null);
  }, [activeTableId]);

  // Load the live room charge + VAT so the till never shows a stale amount
  // after management changes the charge in Settings.
  useEffect(() => {
    let cancelled = false;
    (async () => {
      try {
        const res = await fetch("/api/billing-config");
        const data = await res.json();
        if (!cancelled && res.ok && data) {
          setBillingConfig({
            roomChargeCents: Number(data.roomChargeCents ?? 3000),
            taxRatePercent: Number(data.taxRatePercent ?? 15),
            compBreakfastEnabled: data.compBreakfastEnabled !== false,
          });
        }
      } catch {
        /* keep the GH₵30 / 15% defaults already in state */
      }
    })();
    return () => {
      cancelled = true;
    };
  }, []);

  useEffect(() => {
    if (resetKey > 0) {
      setCart([]);
      setDiscountPercent(0);
      setDiscountAmount(0);
      setDiscountReason("");
      setTipAmount(0);
      setOrderNotes("");
      setIsComplimentary(false);
      setCustomerName("Walk-in Guest");
      setCustomerPhone("");
      setRoomNumber("");
      setSelectedTableId(activeTableId ?? null);
    }
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [resetKey]);

  // Post-payment receipt modal
  const [lastCompletedOrder, setLastCompletedOrder] = useState<any | null>(null);
  const [showReceipt, setShowReceipt] = useState(false);

  // Kitchen docket printing. The kitchen has no terminal access, so every
  // order that goes to the line must be printed and physically delivered.
  const [kitchenTicketOrder, setKitchenTicketOrder] = useState<any | null>(null);
  const [showKitchenTicket, setShowKitchenTicket] = useState(false);
  /** Receipt deferred until the docket has been printed on paid orders. */
  const [pendingReceipt, setPendingReceipt] = useState<any | null>(null);

  // Filtered menu items
  const filteredItems = useMemo(() => {
    return menuItems.filter((item) => {
      const matchCat = selectedCategory === "all" || item.categoryId === selectedCategory;
      const matchSearch =
        !searchQuery ||
        item.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
        item.sku?.toLowerCase().includes(searchQuery.toLowerCase());
      return matchCat && matchSearch && item.isAvailable;
    });
  }, [menuItems, selectedCategory, searchQuery]);

  // Click menu item -> open modifier modal if item has modifiers, or add directly to cart
  const handleItemClick = (item: any) => {
    if (item.modifiers && item.modifiers.length > 0) {
      setSelectedItemForMod(item);
      setItemModSelections({});
      setItemSpecialNotes("");
    } else {
      addItemToCart(item, [], "");
    }
  };

  const addItemToCart = (item: any, selectedMods: any[], specialNotes: string) => {
    let modPriceTotal = 0;
    selectedMods.forEach((m) => {
      modPriceTotal += Number(m.priceDelta || 0);
    });

    const unitPrice = Number(item.price) + modPriceTotal;

    // Check if identical item with identical modifiers exists
    const cartItemId = `${item.id}-${JSON.stringify(selectedMods)}-${specialNotes}`;
    const existingIndex = cart.findIndex((ci) => ci.cartItemId === cartItemId);

    if (existingIndex > -1) {
      const updated = [...cart];
      updated[existingIndex].quantity += 1;
      updated[existingIndex].totalPrice = (updated[existingIndex].quantity * unitPrice).toFixed(2);
      setCart(updated);
    } else {
      setCart([
        ...cart,
        {
          cartItemId,
          menuItemId: item.id,
          itemName: item.name,
          quantity: 1,
          basePrice: Number(item.price),
          unitPrice: unitPrice,
          totalPrice: unitPrice.toFixed(2),
          costPrice: item.costPrice || "0.00",
          modifiers: selectedMods,
          specialInstructions: specialNotes,
          station: item.station || "kitchen",
        },
      ]);
    }
  };

  const updateQuantity = (index: number, delta: number) => {
    const updated = [...cart];
    const newQty = updated[index].quantity + delta;
    if (newQty <= 0) {
      updated.splice(index, 1);
    } else {
      updated[index].quantity = newQty;
      updated[index].totalPrice = (newQty * updated[index].unitPrice).toFixed(2);
    }
    setCart(updated);
  };

  const removeCartItem = (index: number) => {
    const updated = [...cart];
    updated.splice(index, 1);
    setCart(updated);
  };

  const clearCart = () => {
    setCart([]);
    setDiscountPercent(0);
    setDiscountAmount(0);
    setTipAmount(0);
  };

  const handleNewTicketLocal = () => {
    setCart([]);
    setDiscountPercent(0);
    setDiscountAmount(0);
    setDiscountReason("");
    setTipAmount(0);
    setOrderNotes("");
    setIsComplimentary(false);
    setCustomerName("Walk-in Guest");
    setCustomerPhone("");
    setRoomNumber("");
    setSelectedTableId(null);
    setOrderType("dine_in");
  };

  // ---------------------------------------------------------------------
  // Bill maths — the SAME function the server uses (pricing-core), so the
  // total displayed here is exactly the total that gets charged.
  // ---------------------------------------------------------------------
  const pricing = useMemo(
    () =>
      priceOrder({
        lines: cart.map((it) => ({
          unitPrice: it.unitPrice,
          quantity: it.quantity,
        })),
        orderType,
        discountCents: toCents(discountAmount),
        discountPercent,
        tipCents: toCents(tipAmount),
        isComplimentary,
        config: billingConfig,
      }),
    [cart, orderType, discountAmount, discountPercent, tipAmount, isComplimentary, billingConfig]
  );

  const subtotal = pricing.subtotalCents / 100;
  const calculatedDiscount = pricing.discountCents / 100;
  const taxAmount = pricing.taxCents / 100;
  const roomCharge = pricing.roomChargeCents / 100;
  const serviceCharge = 0;
  const totalAmount = pricing.totalCents / 100;

  /** Builds the printable kitchen docket from whatever we know locally. */
  const buildKitchenTicket = (order: any, items: any[]) => {
    const table = tables.find((t) => t.id === (order.tableId ?? selectedTableId));
    return {
      ...order,
      tableNumber: table?.tableNumber,
      roomNumber: order.roomNumber || (orderType === "room_service" ? roomNumber : null),
      items,
    };
  };

  // Handle Save / Send to Kitchen
  const handleSendToKitchen = async () => {
    if (cart.length === 0) return;
    if (orderType === "room_service" && !roomNumber.trim()) {
      alert("Enter the hotel room number before sending a Room Service order.");
      return;
    }
    setIsSubmitting(true);

    // Totals here are a preview only; the server re-prices the bill from the
    // menu database and the live settings, so these fields are informational.
    const payload = {
      branchId: currentUser.branchId,
      tableId: orderType === "dine_in" ? selectedTableId : null,
      roomNumber: orderType === "room_service" ? roomNumber.trim() : null,
      userId: currentUser.id,
      customerName,
      customerPhone,
      orderType,
      discountAmount: calculatedDiscount.toFixed(2),
      discountReason,
      tipAmount: tipAmount.toFixed(2),
      notes: orderNotes,
      items: cart,
      sendToKitchen: true,
      isComplimentary,
      complimentaryReason: isComplimentary ? compReason : undefined,
      idempotencyKey: `ORD-${Date.now()}-${Math.random()}`,
    };

    try {
      if (!navigator.onLine) {
        // Offline PWA Mode!
        queueOfflineOrder({
          ...payload,
          clientTimestamp: Date.now(),
          paidAmount: 0,
          paymentMethod: "unpaid",
          paymentStatus: "unpaid",
          subtotal,
          taxAmount,
          serviceCharge,
          discountAmount: calculatedDiscount,
          tipAmount,
          totalAmount,
        });
        alert("System is currently offline. Order safely buffered in offline queue and will auto-sync upon reconnection!");
        clearCart();
        setIsSubmitting(false);
        return;
      }

      const res = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(payload),
      });

      const data = await res.json();
      if (data.success) {
        clearCart();
        if (onOrderCreated) onOrderCreated();
        // The kitchen has no screen, so the printed docket IS the order.
        setKitchenTicketOrder(buildKitchenTicket(data.order, cart));
        setShowKitchenTicket(true);
      } else {
        alert(data.error || "Failed to create order");
      }
    } catch {
      alert("Network error: buffered locally");
    } finally {
      setIsSubmitting(false);
    }
  };

  // Handle Pay and Settle Bill (Cash, MoMo, or Split)
  const handleProcessPayment = async () => {
    if (cart.length === 0) return;
    if (orderType === "room_service" && !roomNumber.trim()) {
      alert("Enter the hotel room number before settling a Room Service order.");
      return;
    }
    setIsSubmitting(true);

    const payMethod = paymentMethod; // "cash" | "momo" | "split"
    const tenderedCashNum = cashTendered ? Number(cashTendered) : totalAmount;

    let payloadCashAmount: number | undefined = undefined;
    let payloadMomoAmount: number | undefined = undefined;
    let payloadCashTendered: string | null = null;
    let payloadReference: string = "CASH-REGISTER";

    if (payMethod === "cash") {
      payloadCashTendered = tenderedCashNum.toFixed(2);
      payloadReference = "CASH-REGISTER";
    } else if (payMethod === "momo") {
      payloadReference = momoRef.trim() || `MOMO-${Date.now().toString().slice(-6)}`;
    } else if (payMethod === "split") {
      const cPart = Number(splitCashAmount || 0);
      const mPart = Number(splitMomoAmount || 0);
      const cTendered = splitCashTendered ? Number(splitCashTendered) : cPart;
      payloadCashAmount = cPart;
      payloadMomoAmount = mPart;
      payloadCashTendered = cTendered.toFixed(2);
      payloadReference = momoRef.trim() || `MOMO-SPLIT-${Date.now().toString().slice(-6)}`;
    }

    // The server re-prices from the menu database + live settings; these
    // totals are a preview only and are deliberately not sent as authoritative.
    const orderPayload = {
      branchId: currentUser.branchId,
      tableId: orderType === "dine_in" ? selectedTableId : null,
      roomNumber: orderType === "room_service" ? roomNumber.trim() : null,
      userId: currentUser.id,
      customerName,
      customerPhone: customerPhone || null,
      orderType,
      discountAmount: calculatedDiscount.toFixed(2),
      discountReason,
      tipAmount: tipAmount.toFixed(2),
      notes: orderNotes,
      items: cart,
      sendToKitchen: true,
      isComplimentary,
      complimentaryReason: isComplimentary ? compReason : undefined,
      idempotencyKey: `ORD-${Date.now()}-${Math.random()}`,
    };

    try {
      const resOrder = await fetch("/api/orders", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(orderPayload),
      });
      const orderData = await resOrder.json();

      if (!orderData.success) {
        alert(orderData.error || "Failed to create order");
        setIsSubmitting(false);
        return;
      }

      const createdOrder = orderData.order;

      // A complimentary order is already settled by the server at GH₵0.00 —
      // there is no tender to record, so skip the payment call entirely and
      // go straight to printing the kitchen docket.
      if (isComplimentary) {
        const compReceipt = {
          ...createdOrder,
          items: createdOrder.items?.length ? createdOrder.items : cart,
          paidAmount: "0.00",
          paymentMethod: "COMPLIMENTARY",
          changeGiven: "0.00",
        };

        setShowPayModal(false);
        const docketItems = cart;
        clearCart();
        if (onOrderCreated) onOrderCreated();
        setKitchenTicketOrder(buildKitchenTicket(createdOrder, docketItems));
        setPendingReceipt(compReceipt);
        setShowKitchenTicket(true);
        setIsSubmitting(false);
        return;
      }

      // Now process payment
      const payRes = await fetch(`/api/orders/${createdOrder.id}/pay`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          amount: totalAmount.toFixed(2),
          paymentMethod: payMethod,
          cashTendered: payloadCashTendered,
          referenceNumber: payloadReference,
          cashAmount: payloadCashAmount,
          momoAmount: payloadMomoAmount,
          userId: currentUser.id,
          releaseTable: true,
        }),
      });

      const payData = await payRes.json();
      if (payData.success) {
        const receiptOrder = {
          ...createdOrder,
          items: cart,
          paidAmount: totalAmount.toFixed(2),
          paymentMethod:
            payMethod === "split"
              ? "Split (Cash + MoMo)"
              : payMethod === "momo"
              ? "Mobile Money (MoMo)"
              : "Cash",
          referenceNumber: payloadReference,
          cashTendered: payloadCashTendered,
          changeGiven: payData.changeGiven,
          splitDetails:
            payMethod === "split"
              ? {
                  cashAmount: payloadCashAmount?.toFixed(2),
                  momoAmount: payloadMomoAmount?.toFixed(2),
                }
              : undefined,
        };

        setShowPayModal(false);
        clearCart();
        if (onOrderCreated) onOrderCreated();

        // Print the kitchen docket first; the customer receipt follows once
        // the docket has been handed to the line.
        if (cart.length > 0) {
          setKitchenTicketOrder(buildKitchenTicket(createdOrder, cart));
          setPendingReceipt(receiptOrder);
          setShowKitchenTicket(true);
        } else {
          setLastCompletedOrder(receiptOrder);
          setShowReceipt(true);
        }
      } else {
        alert(payData.error || "Payment failed");
      }
    } catch (e: any) {
      alert("Payment processing error: " + e.message);
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleApplyModifierModal = () => {
    if (!selectedItemForMod) return;

    // Collect chosen modifier options
    const chosenOptions: any[] = [];
    Object.values(itemModSelections).forEach((opt: any) => {
      if (opt) chosenOptions.push(opt);
    });

    addItemToCart(selectedItemForMod, chosenOptions, itemSpecialNotes);
    setSelectedItemForMod(null);
  };

  return (
    <div className="flex-1 flex flex-col h-full overflow-hidden bg-neutral-950">
      {/* POS COMPUTER QUICK NAV — one-tap jumps between the 5 till screens.
          Big 56px targets designed for touchscreen terminals. */}
      <div className="shrink-0 bg-neutral-900 border-b border-neutral-800 px-3 py-2 flex items-center gap-2 overflow-x-auto custom-scrollbar">
        <button
          onClick={handleNewTicketLocal}
          className="h-14 px-5 shrink-0 rounded-2xl bg-amber-500 hover:bg-amber-400 active:bg-amber-600 text-black font-bold text-sm flex items-center gap-2 shadow-md transition active:scale-[0.97]"
          title="Clear the ticket and start a new order"
        >
          <Plus className="w-5 h-5" strokeWidth={3} />
          <span>New Ticket</span>
        </button>
        {onGoTables && (
          <button
            onClick={onGoTables}
            className="h-14 px-5 shrink-0 rounded-2xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-white font-bold text-sm flex items-center gap-2 transition active:scale-[0.97]"
            title="Go to tables & floor plan"
          >
            <span className="text-lg leading-none">▦</span>
            <span>Tables</span>
          </button>
        )}
        {onGoOrders && (
          <button
            onClick={onGoOrders}
            className="h-14 px-5 shrink-0 rounded-2xl bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-white font-bold text-sm flex items-center gap-2 transition active:scale-[0.97]"
            title="Go to past orders"
          >
            <Receipt className="w-5 h-5 text-neutral-300" />
            <span>Orders</span>
          </button>
        )}
        {onOpenDrawer && (
          <button
            onClick={onOpenDrawer}
            className="h-14 px-5 shrink-0 rounded-2xl bg-emerald-600/20 hover:bg-emerald-600/30 border border-emerald-500/50 text-emerald-300 font-bold text-sm flex items-center gap-2 transition active:scale-[0.97]"
            title="Open the cash drawer screen"
          >
            <Coins className="w-5 h-5" />
            <span>Cash Drawer</span>
          </button>
        )}
        <div className="ml-auto hidden md:flex items-center gap-2 text-xs text-neutral-400 shrink-0 pr-1">
          <span className="font-mono font-bold text-amber-400 text-base">GH₵{totalAmount.toFixed(2)}</span>
          <span>· {cart.reduce((n, it) => n + it.quantity, 0)} items</span>
        </div>
      </div>

      <div className="flex-1 flex flex-col lg:flex-row min-h-0 overflow-hidden">
      {/* LEFT/CENTER: Ghanaian Menu Items & Categories */}
      <div className="flex-1 flex flex-col h-full border-r border-neutral-800 overflow-hidden">
        {/* Top search & Filter bar */}
        <div className="p-4 bg-neutral-900 border-b border-neutral-800 flex flex-col sm:flex-row gap-3 items-center justify-between">
          <div className="relative w-full sm:w-80">
            <Search className="w-4 h-4 text-neutral-400 absolute left-3 top-1/2 -translate-y-1/2" />
            <input
              type="text"
              placeholder="Search Jollof, Waakye, Tilapia, Banku..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full pl-9 pr-4 py-2 bg-neutral-800 border border-neutral-700 rounded-xl text-sm text-white placeholder-neutral-400 focus:outline-none focus:border-amber-500"
            />
            {searchQuery && (
              <button
                onClick={() => setSearchQuery("")}
                className="absolute right-3 top-1/2 -translate-y-1/2 text-neutral-400 hover:text-white"
              >
                <X className="w-4 h-4" />
              </button>
            )}
          </div>

          {/* Table Indicator if table active */}
          {selectedTableId && (
            <div className="px-3 py-1.5 bg-amber-500/10 border border-amber-500/30 rounded-xl flex items-center gap-2 text-xs font-semibold text-amber-400">
              <span>Ordering for Table #{selectedTableId}</span>
              <button
                onClick={() => setSelectedTableId(null)}
                className="text-neutral-400 hover:text-white"
              >
                <X className="w-3.5 h-3.5" />
              </button>
            </div>
          )}
        </div>

        {/* Category Pills */}
        <div className="px-4 py-3 bg-neutral-900/50 border-b border-neutral-800 flex items-center gap-2 overflow-x-auto custom-scrollbar shrink-0">
          <button
            onClick={() => setSelectedCategory("all")}
            className={`px-5 h-11 rounded-xl text-[13px] font-bold whitespace-nowrap transition-all active:scale-95 ${
              selectedCategory === "all"
                ? "bg-amber-500 text-black shadow-md shadow-amber-500/20"
                : "bg-neutral-800 text-neutral-300 hover:bg-neutral-750 hover:text-white"
            }`}
          >
            All Dishes ({menuItems.length})
          </button>
          {categories.map((cat) => (
            <button
              key={cat.id}
              onClick={() => setSelectedCategory(cat.id)}
              className={`px-5 h-11 rounded-xl text-[13px] font-bold whitespace-nowrap transition-all active:scale-95 ${
                selectedCategory === cat.id
                  ? "bg-amber-500 text-black shadow-md shadow-amber-500/20"
                  : "bg-neutral-800 text-neutral-300 hover:bg-neutral-750 hover:text-white"
              }`}
            >
              {cat.name}
            </button>
          ))}
        </div>

        {/* Item Cards Grid */}
        <div className="flex-1 overflow-y-auto p-4 custom-scrollbar">
          <div className="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-4 2xl:grid-cols-5 gap-4">
            {filteredItems.map((item) => (
              <div
                key={item.id}
                role="button"
                tabIndex={0}
                onClick={() => handleItemClick(item)}
                onKeyDown={(e) => {
                  if (e.key === "Enter" || e.key === " ") {
                    e.preventDefault();
                    handleItemClick(item);
                  }
                }}
                className="group relative bg-neutral-900 hover:bg-neutral-850 active:bg-neutral-800 border border-neutral-800 hover:border-amber-500/50 active:border-amber-500 rounded-2xl p-3.5 flex flex-col justify-between cursor-pointer transition-all duration-150 hover:shadow-xl hover:shadow-amber-500/5 select-none"
              >
                <div>
                  {/* Photo with badges */}
                  <div className="relative w-full h-32 rounded-xl overflow-hidden bg-neutral-800 mb-3">
                    {item.imageUrl ? (
                      <img
                        src={item.imageUrl}
                        alt={item.name}
                        className="w-full h-full object-cover group-hover:scale-105 transition duration-300"
                        loading="lazy"
                      />
                    ) : (
                      <div className="w-full h-full flex items-center justify-center text-neutral-600">
                        <Coffee className="w-8 h-8" />
                      </div>
                    )}
                    {item.hasRecipe && (
                      <div className="absolute top-2 left-2 px-1.5 py-0.5 rounded-md bg-black/70 backdrop-blur-xs text-[10px] text-amber-300 font-medium flex items-center gap-1 border border-amber-500/30">
                        <ChefHat className="w-3 h-3" />
                        <span>Recipe</span>
                      </div>
                    )}
                    <div className="absolute bottom-2 right-2 px-2.5 py-1 rounded-lg bg-neutral-950/85 backdrop-blur-xs text-[13px] font-bold text-emerald-400 border border-neutral-700">
                      GH₵{Number(item.price).toFixed(2)}
                    </div>
                  </div>

                  <h4 className="font-bold text-neutral-50 text-[13.5px] leading-snug line-clamp-2">
                    {item.name}
                  </h4>
                  {item.sku && (
                    <div className="text-[10px] text-neutral-500 mt-0.5 font-mono">
                      {item.sku}
                    </div>
                  )}
                </div>

                <div className="mt-3 pt-2.5 border-t border-neutral-800/80 flex items-center justify-between text-[11.5px] text-neutral-400">
                  <span className="capitalize text-neutral-500">{item.station || "Kitchen"}</span>
                  <span className="w-8 h-8 rounded-lg bg-amber-500/10 text-amber-400 group-hover:bg-amber-500 group-hover:text-black flex items-center justify-center font-bold transition text-lg leading-none">
                    +
                  </span>
                </div>
              </div>
            ))}
          </div>

          {filteredItems.length === 0 && (
            <div className="h-64 flex flex-col items-center justify-center text-center p-6 text-neutral-500">
              <Search className="w-10 h-10 mb-2 opacity-40" />
              <p className="text-sm font-medium">No dishes match your search.</p>
              <p className="text-xs text-neutral-600 mt-1">Try changing category or search terms.</p>
            </div>
          )}
        </div>
      </div>

      {/* RIGHT: Active Order Cart & Totals Panel */}
      <div className="w-full lg:w-96 bg-neutral-900 border-l border-neutral-800 flex flex-col h-full shrink-0">
        {/* Order Meta Header */}
        <div className="p-4 border-b border-neutral-800 space-y-3">
          {/* Order Type Selector — Room Service is distinct from restaurant
              table dining because the GH₵ room charge applies only there. */}
          <div className="grid grid-cols-4 gap-1 bg-neutral-950 p-1 rounded-xl border border-neutral-800 text-[11px] font-bold">
            {([
              ["dine_in", "Table"],
              ["room_service", "Room Service"],
              ["takeaway", "Takeaway"],
              ["delivery", "Delivery"],
            ] as const).map(([type, label]) => (
              <button
                key={type}
                onClick={() => {
                  setOrderType(type);
                  if (type !== "dine_in") setSelectedTableId(null);
                  if (type !== "room_service") setIsComplimentary(false);
                  if (type !== "room_service") setRoomNumber("");
                }}
                className={`h-11 px-1 rounded-lg transition active:scale-[0.97] ${
                  orderType === type
                    ? type === "room_service"
                      ? "bg-sky-400 text-black shadow-xs"
                      : "bg-amber-500 text-black shadow-xs"
                    : "text-neutral-400 hover:text-white"
                }`}
              >
                {label}
              </button>
            ))}
          </div>

          {/* Table / Room Number / Guest contact */}
          <div className="grid grid-cols-2 gap-2 text-xs">
            {orderType === "dine_in" ? (
              <div>
                <label className="text-[10px] text-neutral-400 font-medium block mb-1">
                  Table Number
                </label>
                <select
                  value={selectedTableId || ""}
                  onChange={(e) => setSelectedTableId(e.target.value ? Number(e.target.value) : null)}
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-2.5 h-11 text-white focus:outline-none focus:border-amber-500"
                >
                  <option value="">Select Table...</option>
                  {tables.map((tbl) => (
                    <option key={tbl.id} value={tbl.id}>
                      {tbl.tableNumber} ({tbl.capacity}p - {tbl.status})
                    </option>
                  ))}
                </select>
              </div>
            ) : orderType === "room_service" ? (
              <div>
                <label className="text-[10px] text-sky-300 font-semibold block mb-1">
                  Hotel Room Number *
                </label>
                <input
                  type="text"
                  value={roomNumber}
                  onChange={(e) => setRoomNumber(e.target.value)}
                  placeholder="e.g. 204"
                  className="w-full bg-neutral-800 border border-sky-500/40 rounded-lg px-3 h-11 text-white font-bold placeholder:text-neutral-500 focus:outline-none focus:border-sky-400"
                />
              </div>
            ) : (
              <div>
                <label className="text-[10px] text-neutral-400 font-medium block mb-1">
                  Guest Phone (optional)
                </label>
                <div className="relative">
                  <Phone className="w-3.5 h-3.5 text-neutral-500 absolute left-3 top-1/2 -translate-y-1/2" />
                  <input
                    type="tel"
                    value={customerPhone}
                    onChange={(e) => setCustomerPhone(e.target.value)}
                    placeholder="024 410 0000"
                    className="w-full bg-neutral-800 border border-neutral-700 rounded-lg pl-9 pr-2 h-11 text-white focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}

            <div>
              <label className="text-[10px] text-neutral-400 font-medium block mb-1">
                Guest Name
              </label>
              <div className="relative">
                <User className="w-3 h-3 text-neutral-500 absolute left-2 top-1/2 -translate-y-1/2" />
                <input
                  type="text"
                  value={customerName}
                  onChange={(e) => setCustomerName(e.target.value)}
                  placeholder="Walk-in Guest"
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-lg pl-6 pr-2 py-1.5 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>
          </div>
          <div>
            <label className="text-[10px] text-neutral-400 font-medium block mb-1">
              Order Note (prints on kitchen docket)
            </label>
            <input
              type="text"
              value={orderNotes}
              onChange={(e) => setOrderNotes(e.target.value)}
              placeholder="e.g. Birthday — extra shito on side"
              className="w-full bg-neutral-800 border border-neutral-700 rounded-lg px-2.5 py-2 text-xs text-white placeholder:text-neutral-500 focus:outline-none focus:border-amber-500"
            />
          </div>
        </div>

        {/* Cart Item List */}
        <div className="flex-1 overflow-y-auto p-4 space-y-2.5 custom-scrollbar">
          {cart.length === 0 ? (
            <div className="h-full flex flex-col items-center justify-center text-center text-neutral-500 p-6">
              <Receipt className="w-12 h-12 mb-2 opacity-30 text-amber-500" />
              <p className="text-sm font-semibold text-neutral-300">Ticket is empty</p>
              <p className="text-xs text-neutral-500 mt-1">Tap Ghanaian dishes on the left to start the order</p>
            </div>
          ) : (
            cart.map((it, idx) => (
              <div
                key={it.cartItemId || idx}
                className="bg-neutral-855 border border-neutral-750 rounded-xl p-3 text-xs space-y-2 group"
              >
                <div className="flex justify-between items-start gap-2">
                  <div className="flex-1">
                    <span className="font-semibold text-neutral-100">{it.itemName}</span>
                    {it.modifiers && it.modifiers.length > 0 && (
                      <div className="text-[11px] text-amber-400/90 mt-0.5">
                        {it.modifiers.map((m: any, mIdx: number) => (
                          <span key={mIdx} className="mr-2">
                            + {m.name || m.optionName}
                          </span>
                        ))}
                      </div>
                    )}
                    {it.specialInstructions && (
                      <div className="text-[10px] text-neutral-400 italic mt-0.5">
                        * {it.specialInstructions}
                      </div>
                    )}
                  </div>
                  <div className="text-right font-mono font-bold text-neutral-200">
                    GH₵{Number(it.totalPrice).toFixed(2)}
                  </div>
                </div>

                <div className="flex items-center justify-between pt-2 border-t border-neutral-800">
                  <span className="text-[11px] text-neutral-500">
                    GH₵{Number(it.unitPrice).toFixed(2)} ea
                  </span>
                  {/* Oversized steppers: cashiers adjust quantities constantly
                      while looking at the guest, not the screen. */}
                  <div className="flex items-center gap-1.5">
                    <button
                      onClick={() => updateQuantity(idx, -1)}
                      aria-label="Decrease quantity"
                      className="w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 text-neutral-200 flex items-center justify-center transition active:scale-95"
                    >
                      <Minus className="w-5 h-5" strokeWidth={3} />
                    </button>
                    <span className="w-9 text-center font-bold text-white font-mono text-base">
                      {it.quantity}
                    </span>
                    <button
                      onClick={() => updateQuantity(idx, 1)}
                      aria-label="Increase quantity"
                      className="w-10 h-10 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:bg-amber-500 active:text-black text-neutral-200 flex items-center justify-center transition active:scale-95"
                    >
                      <Plus className="w-5 h-5" strokeWidth={3} />
                    </button>
                    <button
                      onClick={() => removeCartItem(idx)}
                      aria-label="Remove item"
                      className="ml-0.5 w-10 h-10 rounded-xl text-neutral-500 hover:text-rose-400 hover:bg-rose-500/10 flex items-center justify-center transition"
                      title="Remove item"
                    >
                      <Trash2 className="w-[18px] h-[18px]" />
                    </button>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>

        {/* Order Calculations & Checkout Bar */}
        <div className="p-4 bg-neutral-900 border-t border-neutral-800 space-y-3">
          {/* Quick Discount & Tip Triggers */}
          <div className="flex gap-2 text-xs">
            <button
              onClick={() => setShowDiscountModal(true)}
              className={`flex-1 h-11 px-2 rounded-xl border flex items-center justify-center gap-1.5 font-semibold text-[12.5px] transition active:scale-95 ${
                calculatedDiscount > 0
                  ? "bg-amber-500/10 border-amber-500/40 text-amber-400"
                  : "bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-750"
              }`}
            >
              <Percent className="w-3.5 h-3.5" />
              <span>
                {calculatedDiscount > 0 ? `-GH₵${calculatedDiscount.toFixed(2)} Disc` : "Discount"}
              </span>
            </button>

            {/* Quick Tip selection */}
            <div className="flex-1 flex gap-1">
              {[0.05, 0.10, 0.15].map((pct) => {
                const tipVal = subtotal * pct;
                const isSelected = Math.abs(tipAmount - tipVal) < 0.05;
                return (
                  <button
                    key={pct}
                    onClick={() => setTipAmount(isSelected ? 0 : tipVal)}
                    className={`flex-1 h-11 rounded-xl border text-[13px] font-bold transition active:scale-95 ${
                      isSelected
                        ? "bg-emerald-500/20 border-emerald-500/40 text-emerald-400"
                        : "bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-white"
                    }`}
                  >
                    {pct * 100}%
                  </button>
                );
              })}
            </div>
          </div>

          {/* Complimentary breakfast toggle */}
          {orderType === "room_service" && billingConfig.compBreakfastEnabled && (
            <button
              onClick={() => (isComplimentary ? setIsComplimentary(false) : setShowCompModal(true))}
              className={`w-full h-11 rounded-xl border text-[12.5px] font-bold flex items-center justify-center gap-2 transition active:scale-[0.98] ${
                isComplimentary
                  ? "bg-sky-500/20 border-sky-400 text-sky-200"
                  : "bg-neutral-800 border-neutral-700 text-neutral-300 hover:bg-neutral-750"
              }`}
              title="Mark this order as a free breakfast for a room guest"
            >
              <Coffee className="w-4 h-4 shrink-0" />
              <span>
                {isComplimentary ? "✓ Complimentary Breakfast — tap to undo" : "Complimentary Breakfast (GH₵0.00)"}
              </span>
            </button>
          )}

          {/* Subtotals Breakdown (Ghanaian Tax + Room Charge) */}
          <div className="space-y-1 text-xs text-neutral-400">
            <div className="flex justify-between">
              <span>Subtotal:</span>
              <span className="font-mono text-neutral-200">GH₵{subtotal.toFixed(2)}</span>
            </div>
            {calculatedDiscount > 0 && !isComplimentary && (
              <div className="flex justify-between text-amber-400 font-medium">
                <span>Discount:</span>
                <span className="font-mono">-GH₵{calculatedDiscount.toFixed(2)}</span>
              </div>
            )}

            {/* Room-service charge — not applied to restaurant-table dining,
                takeaway or delivery. */}
            {orderType === "room_service" && !isComplimentary && (
              <div className="flex justify-between text-sky-300 font-bold">
                <span>Room Service Charge (Room {roomNumber || "—"}):</span>
                <span className="font-mono">GH₵{roomCharge.toFixed(2)}</span>
              </div>
            )}

            <div className="flex justify-between">
              <span>GRA VAT ({billingConfig.taxRatePercent}%):</span>
              <span className="font-mono text-neutral-200">GH₵{taxAmount.toFixed(2)}</span>
            </div>
            {tipAmount > 0 && !isComplimentary && (
              <div className="flex justify-between text-emerald-400 font-medium">
                <span>Tip:</span>
                <span className="font-mono">+GH₵{tipAmount.toFixed(2)}</span>
              </div>
            )}

            {isComplimentary ? (
              <div className="pt-2 border-t border-neutral-800 space-y-1">
                <div className="flex justify-between items-baseline font-bold text-sky-300 text-base">
                  <span>COMPLIMENTARY:</span>
                  <span className="font-mono text-lg">GH₵0.00</span>
                </div>
                <div className="flex justify-between text-[11px] text-neutral-500">
                  <span>Food value given free:</span>
                  <span className="font-mono">GH₵{fromCents(pricing.compValueCents)}</span>
                </div>
              </div>
            ) : (
              <div className="flex justify-between items-baseline pt-2 border-t border-neutral-800 font-bold text-white text-base">
                <span>Total Payable:</span>
                <span className="font-mono text-amber-400 text-lg">GH₵{totalAmount.toFixed(2)}</span>
              </div>
            )}
          </div>

          {/* Action Buttons — Settle is the hero; docket + drawer + clear sit
              side-by-side underneath for one-thumb till operation. */}
          <div className="space-y-2.5 pt-1">
            {isComplimentary ? (
              /* A comp order has nothing to collect, so it is sent straight
                 through — no payment modal, no tender step. */
              <button
                onClick={handleProcessPayment}
                disabled={cart.length === 0 || isSubmitting}
                className="w-full h-14 px-4 bg-sky-600 hover:bg-sky-500 active:bg-sky-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-2xl text-[15px] font-bold flex items-center justify-center gap-2.5 shadow-lg shadow-sky-600/25 transition active:scale-[0.98]"
              >
                <Coffee className="w-6 h-6 shrink-0" />
                <span>{isSubmitting ? "Sending…" : "Send Comp Order · GH₵0.00"}</span>
              </button>
            ) : (
              <button
                onClick={() => {
                  setCashTendered(totalAmount.toFixed(2));
                  const half = (Math.round((totalAmount / 2) * 100) / 100).toFixed(2);
                  setSplitCashAmount(half);
                  setSplitMomoAmount((totalAmount - Number(half)).toFixed(2));
                  setSplitCashTendered(half);
                  setMomoRef("");
                  setShowPayModal(true);
                }}
                disabled={cart.length === 0 || isSubmitting}
                className="w-full h-14 px-4 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white rounded-2xl text-[15px] font-bold flex items-center justify-center gap-2.5 shadow-lg shadow-emerald-600/25 transition active:scale-[0.98]"
              >
                <DollarSign className="w-6 h-6 text-amber-300 shrink-0" />
                <span>Settle Bill · GH₵{totalAmount.toFixed(2)}</span>
              </button>
            )}

            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={handleSendToKitchen}
                disabled={cart.length === 0 || isSubmitting}
                className="h-12 px-3 bg-neutral-800 hover:bg-neutral-750 active:bg-neutral-700 disabled:opacity-40 disabled:cursor-not-allowed border border-neutral-700 text-white rounded-2xl text-[12px] font-bold flex items-center justify-center gap-2 transition active:scale-[0.98]"
                title="Print the kitchen docket without taking payment"
              >
                <Printer className="w-5 h-5 text-amber-400 shrink-0" />
                <span>Kitchen Docket</span>
              </button>
              {onOpenDrawer ? (
                <button
                  onClick={onOpenDrawer}
                  className="h-12 px-3 bg-emerald-600/15 hover:bg-emerald-600/25 border border-emerald-500/50 text-emerald-300 rounded-2xl text-[12px] font-bold flex items-center justify-center gap-2 transition active:scale-[0.98]"
                  title="Jump to the cash drawer screen"
                >
                  <Coins className="w-5 h-5 shrink-0" />
                  <span>Cash Drawer</span>
                </button>
              ) : (
                <button
                  onClick={handleNewTicketLocal}
                  disabled={cart.length === 0 || isSubmitting}
                  className="h-12 px-3 bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-neutral-300 rounded-2xl text-[12px] font-bold flex items-center justify-center gap-2 transition active:scale-[0.98] disabled:opacity-40"
                  title="Clear the current ticket"
                >
                  <Trash2 className="w-5 h-5 shrink-0" />
                  <span>Clear</span>
                </button>
              )}
            </div>
            {onOpenDrawer && (
              <button
                onClick={handleNewTicketLocal}
                disabled={cart.length === 0 || isSubmitting}
                className="w-full h-10 text-[12px] font-semibold text-neutral-400 hover:text-rose-300 hover:bg-rose-500/10 rounded-xl transition disabled:opacity-40"
              >
                Clear ticket
              </button>
            )}
          </div>
        </div>
      </div>

      {/* MODAL 1: Modifier & Add-on Selection */}
      {selectedItemForMod && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-2xl w-full max-w-lg p-6 shadow-2xl flex flex-col max-h-[90vh]">
            <div className="flex justify-between items-start mb-4">
              <div>
                <h3 className="text-base font-bold text-white">{selectedItemForMod.name}</h3>
                <p className="text-xs text-neutral-400 mt-0.5">Customize protein, pepper preference, and sides</p>
              </div>
              <button
                onClick={() => setSelectedItemForMod(null)}
                className="p-1 text-neutral-400 hover:text-white rounded-md"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="flex-1 overflow-y-auto space-y-4 pr-1 custom-scrollbar">
              {selectedItemForMod.modifiers?.map((mod: any) => (
                <div key={mod.id} className="bg-neutral-850 border border-neutral-800 rounded-xl p-3.5 space-y-2">
                  <div className="flex items-center justify-between text-xs font-semibold text-neutral-200">
                    <span>{mod.name}</span>
                    {mod.isRequired && <span className="text-[10px] text-rose-400 font-bold">*Required</span>}
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {mod.options?.map((opt: any) => {
                      const isSelected = itemModSelections[mod.id]?.id === opt.id;
                      return (
                        <button
                          key={opt.id}
                          type="button"
                          onClick={() =>
                            setItemModSelections({
                              ...itemModSelections,
                              [mod.id]: isSelected ? null : opt,
                            })
                          }
                          className={`p-2.5 rounded-lg border text-left text-xs transition flex items-center justify-between ${
                            isSelected
                              ? "bg-amber-500/20 border-amber-500 text-amber-300 font-semibold"
                              : "bg-neutral-800 border-neutral-700/80 text-neutral-300 hover:bg-neutral-750"
                          }`}
                        >
                          <span>{opt.name}</span>
                          {Number(opt.priceDelta) > 0 && (
                            <span className="font-mono text-neutral-400">
                              +GH₵{Number(opt.priceDelta).toFixed(2)}
                            </span>
                          )}
                        </button>
                      );
                    })}
                  </div>
                </div>
              ))}

              <div>
                <label className="text-xs font-medium text-neutral-300 block mb-1">
                  Special Kitchen Preparation Instructions
                </label>
                <textarea
                  rows={2}
                  value={itemSpecialNotes}
                  onChange={(e) => setItemSpecialNotes(e.target.value)}
                  placeholder="e.g., Extra shito in separate cup, fry plantain soft, no onions on kebab..."
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xl p-2.5 text-xs text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="mt-5 pt-4 border-t border-neutral-800 flex justify-end gap-3">
              <button
                onClick={() => setSelectedItemForMod(null)}
                className="px-4 py-2 text-xs font-medium text-neutral-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleApplyModifierModal}
                className="px-5 py-2 text-xs font-bold bg-amber-500 text-black hover:bg-amber-400 rounded-xl shadow-xs transition"
              >
                Add to Ticket
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2: Discount Modal */}
      {showDiscountModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-2xl w-full max-w-sm p-5 shadow-2xl space-y-4">
            <h3 className="text-sm font-bold text-white flex items-center gap-2">
              <Percent className="w-4 h-4 text-amber-400" />
              <span>Apply Order Discount</span>
            </h3>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-neutral-400 block mb-1">Discount %</label>
                <div className="grid grid-cols-4 gap-1.5">
                  {[5, 10, 15, 20].map((pct) => (
                    <button
                      key={pct}
                      type="button"
                      onClick={() => {
                        setDiscountPercent(pct);
                        setDiscountAmount(0);
                      }}
                      className={`py-2 rounded-lg border font-semibold ${
                        discountPercent === pct
                          ? "bg-amber-500 text-black border-amber-500"
                          : "bg-neutral-800 border-neutral-700 text-neutral-300"
                      }`}
                    >
                      {pct}%
                    </button>
                  ))}
                </div>
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">Fixed GH₵ Amount</label>
                <input
                  type="number"
                  step="1.0"
                  value={discountAmount || ""}
                  onChange={(e) => {
                    setDiscountAmount(Number(e.target.value));
                    setDiscountPercent(0);
                  }}
                  placeholder="0.00"
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>

              <div>
                <label className="text-neutral-400 block mb-1">Discount Reason</label>
                <input
                  type="text"
                  value={discountReason}
                  onChange={(e) => setDiscountReason(e.target.value)}
                  placeholder="e.g. VIP Akwaaba Promo, Staff Discount"
                  className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-3 py-2 text-white focus:outline-none focus:border-amber-500"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-neutral-800">
              <button
                onClick={() => {
                  setDiscountPercent(0);
                  setDiscountAmount(0);
                  setShowDiscountModal(false);
                }}
                className="px-3 py-1.5 text-xs text-rose-400 hover:text-rose-300"
              >
                Clear Discount
              </button>
              <button
                onClick={() => setShowDiscountModal(false)}
                className="px-4 py-1.5 text-xs font-semibold bg-amber-500 text-black rounded-lg"
              >
                Apply
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 2b: Complimentary Breakfast confirmation */}
      {showCompModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-2xl w-full max-w-sm p-5 shadow-2xl space-y-4">
            <div className="flex items-center gap-3">
              <div className="w-11 h-11 rounded-xl bg-sky-500/20 border border-sky-500/40 text-sky-300 flex items-center justify-center shrink-0">
                <Coffee className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-base font-bold text-white">Complimentary Breakfast</h3>
                <p className="text-xs text-neutral-400">Guest pays GH₵0.00</p>
              </div>
            </div>

            <div className="p-3 rounded-xl bg-sky-500/10 border border-sky-500/30 text-[11.5px] text-sky-100 space-y-1">
              <p>
                The order will be recorded at <strong>GH₵0.00</strong> — no VAT and no room charge.
              </p>
              <p className="text-sky-200/80">
                Stock is still deducted and the kitchen docket still prints, because the food is
                genuinely being served. Every comp is written to the audit log for management review.
              </p>
            </div>

            <div>
              <label className="text-xs text-neutral-300 block mb-1">Reason (printed on the docket)</label>
              <input
                type="text"
                value={compReason}
                onChange={(e) => setCompReason(e.target.value)}
                placeholder="Complimentary breakfast — room guest"
                className="w-full bg-neutral-800 border border-neutral-700 rounded-xl px-3 py-2.5 text-sm text-white focus:outline-none focus:border-sky-500"
              />
              <div className="flex flex-wrap gap-1.5 mt-2">
                {["Room guest breakfast", "Manager comp", "Goodwill / complaint", "Staff meal"].map((r) => (
                  <button
                    key={r}
                    type="button"
                    onClick={() => setCompReason(r)}
                    className="px-2.5 h-8 rounded-lg bg-neutral-800 hover:bg-neutral-750 border border-neutral-700 text-[11px] text-neutral-300 transition"
                  >
                    {r}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex justify-between items-center pt-2 border-t border-neutral-800 text-xs">
              <span className="text-neutral-400">Food value forgone:</span>
              <span className="font-mono font-bold text-amber-400">GH₵{subtotal.toFixed(2)}</span>
            </div>

            <div className="flex gap-2">
              <button
                onClick={() => setShowCompModal(false)}
                className="flex-1 h-12 rounded-xl bg-neutral-800 text-neutral-200 font-semibold text-sm hover:bg-neutral-750 transition"
              >
                Cancel
              </button>
              <button
                onClick={() => {
                  setIsComplimentary(true);
                  setShowCompModal(false);
                  // A free order has no tender, so clear any payment inputs.
                  setTipAmount(0);
                }}
                className="flex-1 h-12 rounded-xl bg-sky-600 hover:bg-sky-500 text-white font-bold text-sm transition"
              >
                Mark Comp
              </button>
            </div>
          </div>
        </div>
      )}

      {/* MODAL 3: Pay & Settle Modal (Cash, MoMo, or Split) */}
      {showPayModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/70 backdrop-blur-xs p-4">
          <div className="bg-neutral-900 border border-neutral-700 rounded-2xl w-full max-w-md p-6 shadow-2xl space-y-4">
            <div className="flex justify-between items-center">
              <div>
                <h3 className="text-base font-bold text-white">Settle Bill</h3>
                <p className="text-xs text-neutral-400">Total Payable: GH₵{totalAmount.toFixed(2)}</p>
              </div>
              <button
                onClick={() => setShowPayModal(false)}
                className="p-1 text-neutral-400 hover:text-white"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Payment Method Selector — Cash, MoMo, or Both (Split) */}
            <div className="grid grid-cols-3 gap-2 text-xs font-semibold">
              <button
                type="button"
                onClick={() => setPaymentMethod("cash")}
                className={`h-16 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition active:scale-[0.97] ${
                  paymentMethod === "cash"
                    ? "bg-emerald-600/20 border-emerald-500 text-emerald-400 font-bold shadow-xs"
                    : "bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-white"
                }`}
              >
                <DollarSign className="w-4 h-4 text-emerald-400" />
                <span>Cash (GH₵)</span>
              </button>

              <button
                type="button"
                onClick={() => setPaymentMethod("momo")}
                className={`h-16 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition active:scale-[0.97] ${
                  paymentMethod === "momo"
                    ? "bg-amber-500/20 border-amber-500 text-amber-300 font-bold shadow-xs"
                    : "bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-white"
                }`}
              >
                <Smartphone className="w-4 h-4 text-amber-400" />
                <span>MoMo</span>
              </button>

              <button
                type="button"
                onClick={() => {
                  setPaymentMethod("split");
                  if (!splitCashAmount || Number(splitCashAmount) === 0) {
                    const half = (Math.round((totalAmount / 2) * 100) / 100).toFixed(2);
                    setSplitCashAmount(half);
                    setSplitMomoAmount((totalAmount - Number(half)).toFixed(2));
                    setSplitCashTendered(half);
                  }
                }}
                className={`h-16 rounded-2xl border-2 flex flex-col items-center justify-center gap-1 transition active:scale-[0.97] ${
                  paymentMethod === "split"
                    ? "bg-purple-500/20 border-purple-500 text-purple-300 font-bold shadow-xs"
                    : "bg-neutral-800 border-neutral-700 text-neutral-400 hover:text-white"
                }`}
              >
                <Coins className="w-4 h-4 text-purple-400" />
                <span>Cash + MoMo</span>
              </button>
            </div>

            {/* TAB 1: Cash Details */}
            {paymentMethod === "cash" && (
              <div className="space-y-3 bg-neutral-850 border border-neutral-800 rounded-xl p-4 text-xs">
                <div>
                  <label className="text-neutral-300 block mb-1 font-semibold">Cash Tendered by Customer (GH₵)</label>
                  <input
                    type="number"
                    step="1.00"
                    value={cashTendered}
                    onChange={(e) => setCashTendered(e.target.value)}
                    className="w-full text-xl font-bold font-mono py-2 px-3 bg-neutral-900 border border-neutral-700 rounded-xl text-white focus:outline-none focus:border-emerald-500"
                  />
                </div>

                {/* Quick tender pills in Ghanaian Cedi notes */}
                <div className="grid grid-cols-4 gap-1.5">
                  <button
                    type="button"
                    onClick={() => setCashTendered(totalAmount.toFixed(2))}
                    className="h-11 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 text-neutral-100 font-bold text-[12.5px] transition active:scale-95"
                  >
                    Exact
                  </button>
                  <button
                    type="button"
                    onClick={() => setCashTendered("100")}
                    className="h-11 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 text-neutral-100 font-bold text-[12.5px] transition active:scale-95"
                  >
                    GH₵100
                  </button>
                  <button
                    type="button"
                    onClick={() => setCashTendered("200")}
                    className="h-11 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 text-neutral-100 font-bold text-[12.5px] transition active:scale-95"
                  >
                    GH₵200
                  </button>
                  <button
                    type="button"
                    onClick={() => setCashTendered("500")}
                    className="h-11 rounded-xl bg-neutral-800 hover:bg-neutral-700 active:bg-neutral-600 text-neutral-100 font-bold text-[12.5px] transition active:scale-95"
                  >
                    GH₵500
                  </button>
                </div>

                {/* Change Given */}
                <div className="pt-2 border-t border-neutral-800 flex justify-between items-baseline font-bold text-sm">
                  <span className="text-neutral-300">Change Due:</span>
                  <span className="text-emerald-400 font-mono text-base">
                    GH₵{Math.max(0, Number(cashTendered || 0) - totalAmount).toFixed(2)}
                  </span>
                </div>
              </div>
            )}

            {/* TAB 2: MoMo Details (Direct indication, no telecom gateway delay) */}
            {paymentMethod === "momo" && (
              <div className="space-y-3 bg-neutral-850 border border-neutral-800 rounded-xl p-4 text-xs">
                <div className="flex items-center gap-2 text-emerald-400 font-semibold text-xs">
                  <CheckCircle2 className="w-4 h-4 shrink-0" />
                  <span>Cashier verifies MoMo transfer on phone/till</span>
                </div>

                <div className="p-3 bg-neutral-900 border border-neutral-800 rounded-lg text-[11px] text-neutral-300 space-y-1">
                  <div className="flex justify-between">
                    <span className="text-neutral-400">Total MoMo Expected:</span>
                    <span className="font-mono font-bold text-amber-400">GH₵{totalAmount.toFixed(2)}</span>
                  </div>
                  <p className="text-[10px] text-neutral-400 pt-1">
                    Customer transfers to restaurant merchant line / scans table GhQR code. Simply tap confirm below once received.
                  </p>
                </div>

                <div>
                  <label className="text-neutral-300 block mb-1 font-semibold text-[11px]">
                    Optional MoMo Note / Sender Reference
                  </label>
                  <input
                    type="text"
                    value={momoRef}
                    onChange={(e) => setMomoRef(e.target.value)}
                    placeholder="e.g. MTN MoMo confirmed / Sender name or TxID"
                    className="w-full px-3 py-2 bg-neutral-900 border border-neutral-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-amber-500"
                  />
                </div>
              </div>
            )}

            {/* TAB 3: Split Payment (Cash + MoMo) */}
            {paymentMethod === "split" && (
              <div className="space-y-3 bg-neutral-850 border border-neutral-800 rounded-xl p-4 text-xs">
                <div className="flex items-center justify-between">
                  <span className="font-bold text-purple-300 text-xs">Split: Cash + MoMo</span>
                  <button
                    type="button"
                    onClick={() => {
                      const half = (Math.round((totalAmount / 2) * 100) / 100).toFixed(2);
                      setSplitCashAmount(half);
                      setSplitMomoAmount((totalAmount - Number(half)).toFixed(2));
                      setSplitCashTendered(half);
                    }}
                    className="px-2 py-0.5 rounded bg-neutral-800 hover:bg-neutral-750 text-neutral-300 text-[10px] font-semibold border border-neutral-700"
                  >
                    50 / 50 Split
                  </button>
                </div>

                <div className="grid grid-cols-2 gap-2.5">
                  <div>
                    <label className="text-neutral-300 block mb-1 font-semibold text-[11px]">
                      Cash Portion (GH₵)
                    </label>
                    <input
                      type="number"
                      step="0.50"
                      value={splitCashAmount}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSplitCashAmount(val);
                        const cVal = Number(val || 0);
                        if (cVal >= 0 && cVal <= totalAmount) {
                          setSplitMomoAmount((totalAmount - cVal).toFixed(2));
                        }
                      }}
                      className="w-full font-bold font-mono py-2 px-3 bg-neutral-900 border border-neutral-700 rounded-xl text-emerald-400 text-sm focus:outline-none focus:border-purple-500"
                    />
                  </div>

                  <div>
                    <label className="text-neutral-300 block mb-1 font-semibold text-[11px]">
                      MoMo Portion (GH₵)
                    </label>
                    <input
                      type="number"
                      step="0.50"
                      value={splitMomoAmount}
                      onChange={(e) => {
                        const val = e.target.value;
                        setSplitMomoAmount(val);
                        const mVal = Number(val || 0);
                        if (mVal >= 0 && mVal <= totalAmount) {
                          setSplitCashAmount((totalAmount - mVal).toFixed(2));
                        }
                      }}
                      className="w-full font-bold font-mono py-2 px-3 bg-neutral-900 border border-neutral-700 rounded-xl text-amber-400 text-sm focus:outline-none focus:border-purple-500"
                    />
                  </div>
                </div>

                {/* Physical cash note tendered for cash portion */}
                <div>
                  <label className="text-neutral-400 block mb-1 text-[11px]">
                    Physical Cash Handed by Customer (GH₵)
                  </label>
                  <input
                    type="number"
                    step="1.00"
                    value={splitCashTendered}
                    onChange={(e) => setSplitCashTendered(e.target.value)}
                    placeholder={splitCashAmount || "0.00"}
                    className="w-full font-mono py-1.5 px-3 bg-neutral-900 border border-neutral-700 rounded-xl text-white text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>

                {/* Real-time breakdown status */}
                {(() => {
                  const cPart = Number(splitCashAmount || 0);
                  const mPart = Number(splitMomoAmount || 0);
                  const covered = cPart + mPart;
                  const remaining = totalAmount - covered;
                  const cTendered = Number(splitCashTendered || cPart);
                  const cashChange = cTendered > cPart ? cTendered - cPart : 0;

                  return (
                    <div className="pt-2 border-t border-neutral-800 space-y-1.5 text-xs">
                      <div className="flex justify-between items-center text-[11px]">
                        <span className="text-neutral-400">Total Covered:</span>
                        <span
                          className={`font-mono font-bold ${
                            Math.abs(remaining) < 0.01 ? "text-emerald-400" : "text-amber-400"
                          }`}
                        >
                          GH₵{covered.toFixed(2)} / GH₵{totalAmount.toFixed(2)}
                        </span>
                      </div>

                      {remaining > 0.01 && (
                        <div className="p-1.5 bg-rose-500/10 border border-rose-500/30 rounded text-[11px] text-rose-300 font-semibold flex justify-between">
                          <span>Balance still owed:</span>
                          <span className="font-mono">GH₵{remaining.toFixed(2)}</span>
                        </div>
                      )}

                      {cashChange > 0 && (
                        <div className="p-1.5 bg-emerald-500/10 border border-emerald-500/30 rounded text-[11px] text-emerald-300 font-bold flex justify-between">
                          <span>Cash Change to Return:</span>
                          <span className="font-mono">GH₵{cashChange.toFixed(2)}</span>
                        </div>
                      )}
                    </div>
                  );
                })()}

                <div>
                  <label className="text-neutral-400 block mb-1 text-[11px]">
                    Optional MoMo Reference / Sender Info
                  </label>
                  <input
                    type="text"
                    value={momoRef}
                    onChange={(e) => setMomoRef(e.target.value)}
                    placeholder="e.g. MoMo received for GH₵ portion"
                    className="w-full px-3 py-1.5 bg-neutral-900 border border-neutral-700 rounded-xl text-white font-mono text-xs focus:outline-none focus:border-purple-500"
                  />
                </div>
              </div>
            )}

            {/* Confirm Payment Button */}
            <button
              onClick={handleProcessPayment}
              disabled={
                isSubmitting ||
                (paymentMethod === "cash" && Number(cashTendered || 0) < totalAmount - 0.01) ||
                (paymentMethod === "split" &&
                  (Number(splitCashAmount || 0) <= 0 ||
                    Number(splitMomoAmount || 0) <= 0 ||
                    Number(splitCashAmount || 0) + Number(splitMomoAmount || 0) < totalAmount - 0.01))
              }
              className="w-full h-16 bg-emerald-600 hover:bg-emerald-500 active:bg-emerald-700 disabled:opacity-40 disabled:cursor-not-allowed text-white font-bold rounded-2xl text-base shadow-lg shadow-emerald-600/25 transition flex items-center justify-center gap-2.5 active:scale-[0.98]"
            >
              <CheckCircle2 className="w-4 h-4" />
              <span>
                {isSubmitting
                  ? "Recording Payment..."
                  : paymentMethod === "momo"
                  ? `Confirm MoMo Payment (GH₵${totalAmount.toFixed(2)})`
                  : paymentMethod === "cash"
                  ? `Confirm Cash Payment (GH₵${totalAmount.toFixed(2)})`
                  : `Confirm Split (GH₵${Number(splitCashAmount || 0).toFixed(2)} Cash + GH₵${Number(splitMomoAmount || 0).toFixed(2)} MoMo)`}
              </span>
            </button>
          </div>
        </div>
      )}

      {/* KITCHEN DOCKET: printed paper ticket sent to the line */}
      {showKitchenTicket && kitchenTicketOrder && (
        <KitchenTicketModal
          isOpen={showKitchenTicket}
          onClose={() => {
            setShowKitchenTicket(false);
            // Reveal the deferred customer receipt after the docket is printed.
            if (pendingReceipt) {
              setLastCompletedOrder(pendingReceipt);
              setPendingReceipt(null);
              setShowReceipt(true);
            }
          }}
          order={kitchenTicketOrder}
        />
      )}

      {/* MODAL 4: Printable Thermal Receipt */}
      {showReceipt && lastCompletedOrder && (
        <ReceiptModal
          isOpen={showReceipt}
          onClose={() => setShowReceipt(false)}
          order={lastCompletedOrder}
        />
      )}
      </div>
    </div>
  );
};
